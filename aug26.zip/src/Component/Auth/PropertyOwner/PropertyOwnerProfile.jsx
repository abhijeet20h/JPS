import React, { useState, useEffect } from 'react';
import Layout from '../../Layout/Layout';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';
import baseApi from "../../../environment/Config";
import { toast } from 'react-toastify';

const PropertyOwnerProfile = () => {
    const navigate = useNavigate();
    const { property } = useParams();
    const { wing } = useParams();
    const { floor } = useParams();
    const { unit } = useParams();
    const { Id } = useParams();
    const { society_name } = useParams();

    const [name, setName] = useState("");
    const [nameErr, setNameErr] = useState("")
    const [email, setEmail] = useState("");
    const [emailErr, setEmailErr] = useState("")
    const [mobileNo, setMobileNo] = useState("")
    const [mobileErr, setMobileErr] = useState("")
    const [iseWhatsApp, setIsWhatsApp] = useState("");
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i;
    const usernameRegex = /^[a-zA-Z ]*$/;


    useEffect(() => {
        window.scrollTo(0, 0)
    }, [])


    // valid Name
    const hadleName = (e) => {
        if (e.target.value.length === 0) {
            setNameErr("Name Should Not Be Blank");
        } else if (e.target.value.length < 2) {
            setNameErr(
                "Name Should Not Less Than 3 Latter"
            );
        } else if (!usernameRegex.test(e.target.value)) {
            setNameErr("username is invalid");
        } else if (e.target.value.length > 2) {
            setNameErr("");
            setName(e.target.value)
        }
    }



    // set valid email
    const handleEmail = (e) => {
        if (!e.target.value) {
            setEmailErr("Email is required!");
        } else if (!regex.test(e.target.value)) {
            setEmailErr("This is not a valid email format!");
        } else if (regex.test(e.target.value)) {
            setEmailErr("");
            setEmail(e.target.value)
        }
    }


    // set valid mobile
    const handleMobileNumber = (e) => {
        if (e.target.value.match(/^(\+\d{1,3}[- ]?)?\d{10}$/) && e.target.value) {
            setMobileNo(e.target.value)
            setMobileErr("")
        } else {
            setMobileNo(null)
            setMobileErr("Enter Valid Mobile Number")
        }
    }


    const handleOtp = (value) => {
        if (!name) {
            setNameErr("Name is required!");
        }
        if (!email) {
            setEmailErr("Email is required!");
        }
        if (!mobileNo) {
            setMobileErr("Enter Valid Mobile Number!");
        }

        if (!nameErr && !emailErr && !mobileErr && name && email && mobileNo) {
            console.log("api call")
            handleSubmit(value)
        } else {
            console.log("not api call")
        }
    }

    const handleSubmit = (value) => {
        var data = JSON.stringify({
            "created_by": Id,
            "property_type": property.toString(),
            "society_name": society_name,
            "wing": wing,
            "floor": floor,
            "flat": unit,
            "name": name,
            "email": email,
            "mobile": mobileNo,
            "wapp_number": iseWhatsApp ? "Yes" : "No",
            "roles": 2
        });

        var config = {
            method: 'post',
            url: `${baseApi.baseUrl}owner/createowner`,
            headers: {
                'Content-Type': 'application/json'
            },
            data: data
        };

        axios(config)
            .then((response) => {
                console.log(JSON.stringify(response.data));
                sendOtp(mobileNo, value)
            })
            .catch(function (error) {
                console.log(error);
            });
    }



    const sendOtp = async (mobileNo, value) => {
        var axios = require('axios');
        var data = JSON.stringify({
            "mobile": mobileNo,
            "roles": 2
        });

        var config = {
            method: 'post',
            url: `${baseApi.baseUrl}owner/sendotp`,
            headers: {
                'Content-Type': 'application/json'
            },
            data: data
        };

        await axios(config)
            .then(function (response) {
                console.log(JSON.stringify(response.data));
                if (response.data.status === 1) {
                    toast(response.data.message);
                    navigatehandle(value)
                } else {
                    toast(response.data.message);
                }
            })
            .catch(function (error) {
                if (error?.response) {
                    toast(error.response.data.message);
                }
            });
    }

    const navigatehandle = (value) => {
        if (value === 1) {
            navigate('/otp_verifiction_owner/' + mobileNo)
        }
        if (value === 2) {
            navigate('/otp_verifiction_owner/' + email)
        }
    }


    return (
        <Layout>
            <div id="property-owner-profile-section"
                className="container-fluid margin-top-first-container-small form-section property-owner-profile-section">
                <div className="container-lg py-4 py-lg-5">
                    <div>
                        <div
                            className="custom-id-card-01 text-purple d-flex flex-row align-items-center justify-content-start justify-content-lg-start">
                            <div className="building-icon mr-3"> <i className="fa fa-building" aria-hidden="true"></i> </div>
                            <div className="building-text d-flex flex-column">
                                <p className="mb-0 fw-600">Personal Profile</p>
                            </div>
                        </div>
                        <div className="progress mb-4 rounded-20">
                            <div className="progress-bar rounded-20 bg-orange" role="progressbar" style={{ width: "50%" }}
                                aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                    </div>
                    <div className="row g-3 g-lg-5">
                        <div className="col-12">
                            <div className="card custom-form-card p-3">
                                <div className="row">
                                    <div className="col-12 col-md-6 col-lg-4 my-2 my-lg-0">
                                        <input type="email" className="form-control" id="exampleFormControlInput1" placeholder="Full Name" maxLength="30" onChange={(e) => hadleName(e)} />
                                        <span className='text-danger mb-0'>{nameErr}</span>
                                    </div>
                                    <div className="col-12 col-md-6 col-lg-4 my-2 my-lg-0">
                                        <input type="email" className="form-control" id="exampleFormControlInput1" placeholder="Email Address" maxLength="30" onChange={(e) => handleEmail(e)} />
                                        <span className='text-danger mb-0'>{emailErr}</span>
                                    </div>
                                    <div className="col-12 col-md-6 col-lg-4 my-2 my-lg-0">
                                        <input type="email" className="form-control" id="exampleFormControlInput1" placeholder="Mobile No." maxLength="10" onChange={(e) => handleMobileNumber(e)} />
                                        <span className='text-danger mb-0'>{mobileErr}</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="col-12">
                            <div className="form-check custom-form-check mb-3">
                                <input className="form-check-input" type="checkbox" value="" id="flexCheckDefault" onChange={(e) => setIsWhatsApp(e.target.checked)} />
                                <label className="form-check-label" htmlFor="flexCheckDefault"> This is my WhatsApp no.
                                </label>
                            </div>
                        </div>
                        <div className="col-12 text-center">
                            <button type="button"
                                className="btn btn-purple-custom text-white px-5 mb-4 me-3" onClick={() => handleOtp(1)}>Verify via OTP</button>
                            <button type="button"
                                className="btn btn-white-custom px-5 mb-4" onClick={() => handleOtp(2)}>Verify via mail</button>
                        </div>
                    </div>
                </div>
            </div>
        </Layout>
    )
}

export default PropertyOwnerProfile