import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from "react-router-dom";
import Layout from '../../Layout/Layout';

const PropertyOwnerRegister = () => {
    const navigate = useNavigate();
    const [chooseProperty, setChooseProperty] = useState('');
    const [wing, setWing] = useState("");
    const [floor, setFloor] = useState("");
    const [unit, setUnit] = useState("");
    const { id } = useParams();
    const { society_name } = useParams();


    useEffect(() => {
        window.scrollTo(0, 0)
    }, [])

    const handleOwnerRegister = () => {
        if (chooseProperty && wing && floor && unit) {
            navigate('/property_owner_profile_info' + '/' + chooseProperty + '/' + wing + '/' + floor + '/' + unit + '/' + id + '/' + society_name)
        }
    }

    return (
        <Layout>
            <div id="property-owner-registration-section"
                className="container-fluid margin-top-first-container-small form-section property-owner-registration-section">
                <div className="container-lg py-4 py-lg-5">
                    <div>
                        <div
                            className="custom-id-card-01 text-purple d-flex flex-row align-items-center justify-content-start justify-content-lg-start">
                            <div className="building-icon mr-3"> <i className="fa fa-building" aria-hidden="true"></i> </div>
                            <div className="building-text d-flex flex-column">
                                <p className="mb-0 fw-600">Flat configuration</p>
                            </div>
                        </div>
                        <div className="progress mb-4 rounded-20">
                            <div className="progress-bar rounded-20 bg-orange" role="progressbar" style={{ width: "0%" }} aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                    </div>
                    <div className="row g-3 gx-lg-5 gy-lg-4">
                        <div className="col-12">

                            <span className="text-20 fw-bold me-3">{society_name === ':society_name' ?  ' ' : society_name}</span>
                        </div>
                        <div className="col-12 col-sm-6 col-md-4">
                            <div className="card custom-form-card p-3">
                                <p className="mb-2 fw-500">Choose Property :</p>
                                <div className="form-check custom-form-check">
                                    <input className="form-check-input" type="radio" name="exampleRadios" id="exampleRadios1"
                                        value="Residential" onChange={e => setChooseProperty(e.target.value)} />
                                    <label className="form-check-label fw-500" htmlFor="exampleRadios1"> Residential </label>
                                </div>
                                <div className="form-check custom-form-check">
                                    <input className="form-check-input" type="radio" name="exampleRadios" id="exampleRadios2"
                                        value="Commercial" onChange={e => setChooseProperty(e.target.value)} />
                                    <label className="form-check-label fw-500" htmlFor="exampleRadios2"> Commercial </label>
                                </div>
                            </div>
                        </div>
                        <div className="col-12 col-sm-6 col-md-8">
                            <div className="card custom-form-card p-3">
                                <label htmlFor="exampleFormControlInput1" className="form-label mb-2">Choose your flat no.</label>
                                <div className="row">
                                    <div className="col-12 col-md-6 col-lg-4">
                                        <div className="input-group mb-3">
                                            <input type="email" className="form-control mb-3" id="exampleFormControlInput1"
                                                placeholder="Enter Wing" onChange={(e) => setWing(e.target.value)} />
                                        </div>
                                    </div>
                                    <div className="col-12 col-md-6 col-lg-4">
                                        <div className="input-group mb-3">
                                            {/*
                                          <select className="form-select fw-400" aria-label="Default select example">
                                                <option value="1">Floor 1</option>
                                                <option value="2">Floor 2</option>
                                            </select>
                                        */}
                                            <input type="email" className="form-control mb-3" id="exampleFormControlInput1"
                                                placeholder="Enter Floor No." onChange={(e) => setFloor(e.target.value)} />

                                        </div>
                                    </div>
                                    <div className="col-12 col-md-6 col-lg-4">
                                        <input type="email" className="form-control mb-3" id="exampleFormControlInput1"
                                            placeholder="Enter Unit No." onChange={(e) => setUnit(e.target.value)} />
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="d-flex flex-column flex-lg-row col-12 justify-content-center align-items-center">
                            <span className="me-2">
                                <button type="button"
                                    onClick={() => handleOwnerRegister()}
                                    className="btn btn-purple-custom text-white px-5 mb-2 under">Next</button>
                            </span>
                            <span className="me-2">
                                <button type="button"
                                    className="btn btn-white-custom text-purple px-5 mb-2 under">Back</button>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </Layout >
    )
}

export default PropertyOwnerRegister