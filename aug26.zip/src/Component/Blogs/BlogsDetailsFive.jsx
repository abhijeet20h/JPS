import React, { useEffect } from 'react';
import Layout from '../Layout/Layout';
import ImageFive from "../../assets/images/blog-img-5.jpg";

const BlogsDetailsFive = () => {

    useEffect(() => {
        window.scrollTo(0, 0)
    }, [])


    return (
        <Layout>
            <div id="blogs-details-section" className="blogs-details-section container-fluid margin-top-first-container-small">
        <div className="container-lg py-4 py-lg-5">
          <nav
            aria-label="breadcrumb"
            className="mb-0 mb-lg-4"
          >
            <ol className="breadcrumb">
              <li className="breadcrumb-item">
                <a href="index.html" className="text-black text-decoration-none fw-bold">Home</a>
              </li>
              <li className="breadcrumb-item active" aria-current="page">
                <span className="text-purple fw-bold">Blogs</span>
              </li>
            </ol>
          </nav>

          <div className="row">
            <div className="col-12 col-lg-6 pb-2 pt-0 pl-lg-4 d-flex flex-column justify-content-center">
              <div className="row">
                <div className="col-12">
                <h2 className="text-start text-lg-start mb-2 mb-lg-4 text-purple fw-bold">
                                Redevelopment - Feasibility Report - types of Reports Advantages and Disadvantages
                                </h2>
                                <hr className="hr-custom-one mb-3 mb-lg-4"></hr>
                </div>
                <div className="col-12  d-flex flex-column justify-content-start">
              <div className='mb-2'>
                  <span className="text-gray">Written By: </span><span>CA S Lakshminarayanan</span>
              </div>
              <div>
                  <span className="text-gray">Date: </span><span>22/02/2022</span>
              </div>
            </div>
              </div>
              
              
            </div>
            <div className="col-12 col-lg-6">
                            <div
                                className="p-3 border rounded-20 grow-cards-wrapper" style={{ backgroundImage: `url(${ImageFive})`, backgroundSize: 'cover' }}
                            >
                            </div>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-12 py-4 pb-0 text-333333">
                            <div className="static-wrap">
                                <p>Every Property which has gone through Redevelopment would have gone through a Feasibility stage either by themselves or through Developer.  Let us understand today what a feasibility report is and whether there are various types of Feasibility Report. Also, how exactly to read a feasibility report.
                                </p>
                                <p>Feasibility Report is a combination of basic calculation of how much Construction area is possible in a Plot as per the present Development Control Regulations in any City (In case of Pune, it is the UDCPR at present along with various GR’s or circulars which follows the UDCPR for clarification) plus the Financial calculation of total cost of the project plus the area that will be required to be sold at existing Market rate by a Developer post which he can provide an increase in area and new amenities & specifications to the existing Owners.</p>

                            </div>

                            <div className="static-wrap">
                                <p>The Factors that affect the Area Feasibility are:</p>
                                <ol className="list-style-decimal">
                                    <li><strong>FSI available in that area - </strong>As per UDCPR according to various bifurcations like TOD/ Non-TOD, Congested/ Non-Congested, Municipal limits/ Outside Municipal limits there are various FSI prescribed. These are based on the Plot Size and/ or Road Width.  These are available in table 6A, 6F, 6G or 14K of UDCPR.</li>
                                    <li><strong>Plot Area – </strong>The higher the Plot Area the bigger the FSI but more importantly the higher the Plot Area the better design fits which can accommodate not only the increased construction but also Parking, Amenities, etc.  Bigger Plot size is a big pull for Developers.</li>
                                    <li><strong>Road Width – </strong>The most important criteria in FSI are the Road width adjoining the Plot as the main approach or abutting (whichever higher). The higher the Road Width the higher the FSI availability since it increases access to the building.</li>
                                </ol>
                            </div>

                            <div className="static-wrap">
                                <p>The cost factors in a Feasibility are:</p>
                                <ol className="list-style-decimal">
                                    <li><strong>Construction Cost - </strong>Due to increase in Raw Material cost in the recent years, the construction cost has increased substantially. A good quality construction can take anywhere between 2600 to 3500 based on the quality of raw material used in a building.  The higher the quality and more the amenities demanded by Owners the Construction cost increases accordingly.</li>
                                    <li><strong>FSI/ TDR/ Challan Cost – </strong>The cost to purchase FSI/ TDR/ Ancillary FSI and challan is a substantial cost to the Developer which usually is demanded upfront to be invested for the safety of the Project.</li>
                                    <li><strong>Payments to Existing Owners  – </strong>– Rent, Deposit, Shifting Charges, Corpus and Betterment charges are payments that Existing owners demand which forms an important part of a Feasibility.</li>
                                    <li><strong>GST and Stamp Duty - </strong>For a Redevelopment Building too GST is to be paid on the total area provided to the Owners and Stamp Duty to be paid on the Increased area provided to the Owners. For ease of transaction and considering that the Owners are senior citizens, the demand is for the Developer to bear the cost hence to be included while considering financial feasibility.</li>
                                    <li><strong>Interest cost / Opportunity cost on Investment for Developer  – </strong>– For the overall investment Developer would also need to pay interest cost or have an opportunity cost for the money invested in the project which would have a % rate of interest in their calculation.</li>
                                    <li><strong>Contingencies – </strong>Raw Material price increase, local dynamics, etc. also calls for some contingency plan for Developers.</li>
                                </ol>
                            </div>

                            <div className="static-wrap">
                                <p>Once all these costs are put together, the Developer would also provide for a reasonable amount of profit over and above the total cost to round off the Pure cost of Redevelopment. Once he can recover these two aspects (Cost + Profit), she/ he would be willing to provide the additional area free of cost to the Existing owner.  An experience Architect and an experienced CA would be an integral partner to put together this report for Property owners. Also a critical point to be noted is that Developer is carrying the risk of Investment and Sale which are the most important variables in a Redevelopment.</p>
                                <p>Feasibility report can be of two kinds:</p>
                                <ol className="list-style-decimal">
                                    <li><strong>Mathematical feasibility - </strong>usually done in a spreadsheet.</li>
                                    <li><strong>Block Diagram feasibility – </strong>Spreadsheet + CAD drawing to determine how the plan fits in the plot.</li>

                                </ol>
                            </div>

                            <div className="static-wrap">
                                <p>Usually, a Block Diagram feasibility is far far superior to the first feasibility and hence recommended to determine what our plot is worth when we go for Redevelopment.</p>
                                <p>Please contact <a href="tel:+917499553592" target='_blank'>7499553592</a> for more info or visit <a href="http://www.dreamsredeveloped.com" target='_blank'>www.dreamsredeveloped.com</a> for the same.</p>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </Layout>
    )
}

export default BlogsDetailsFive