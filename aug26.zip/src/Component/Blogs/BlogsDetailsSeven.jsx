import React, { useEffect } from 'react'
import Layout from '../Layout/Layout'

const BlogsDetailsSeven = () => {

    useEffect(() => {
        window.scrollTo(0, 0)
    }, [])


    return (
        <Layout>
            <div id="blogs-details-section" className="blogs-details-section container-fluid margin-top-first-container-small">
        <div className="container-lg py-4 py-lg-5">
          <nav
            aria-label="breadcrumb"
            className="mb-0 mb-lg-4"
          >
            <ol className="breadcrumb">
              <li className="breadcrumb-item">
                <a href="index.html" className="text-black text-decoration-none fw-bold">Home</a>
              </li>
              <li className="breadcrumb-item active" aria-current="page">
                <span className="text-purple fw-bold">Blogs</span>
              </li>
            </ol>
          </nav>

          <div className="row">
            <div className="col-12 col-lg-6 pb-2 pt-0 pl-lg-4 d-flex flex-column justify-content-center">
              <div className="row">
                <div className="col-12">
                <h2 className="text-start text-lg-start mb-2 mb-lg-4 text-purple fw-bold">
                                Process Of Development  Seven
                                </h2>
                                <hr className="hr-custom-one mb-3 mb-lg-4"></hr>
                </div>
                <div className="col-12  d-flex flex-column justify-content-start">
              <div className='mb-2'>
                  <span className="text-gray">Written By: </span><span>CA S Lakshminarayanan</span>
              </div>
              <div>
                  <span className="text-gray">Date: </span><span>22/02/2022</span>
              </div>
            </div>
              </div>
              
              
            </div>
            <div className="col-12 col-lg-6">
                            <div
                                className="p-3 border rounded-20 grow-cards-wrapper grow-card-img1"
                            >
                            </div>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-12 py-4 pb-0 text-333333">
                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>
                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>
                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>
                        </div>
                    </div>
                </div>
            </div>
        </Layout>
    )
}

export default BlogsDetailsSeven