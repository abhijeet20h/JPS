import React from 'react';
import { useNavigate } from "react-router-dom";
import apartment from "../../../assets/images/apartments-row.jpg";
import AdminRoutes from '../../../App/Route/RouteDetails';

const Livelife = () => {
    const navigate = useNavigate();

    return (
        <div id="livelife-section" className="livelife-section container-fluid">
            <div className="container-lg py-4 py-lg-5">
                <div className="row">
                    <div className="col-12 col-md-6 px-xl-5 pt-0 order-2 order-md-1">
                        <div className="card p-3 border-0">
                            <h2 className="text-left text-purple fw-bold">
                                Live the Life <br />of your Dreams
                            </h2>
                            <p className="text-purple-dark"><strong>Here's How...</strong></p>
                            <p className="text-333333">
                                India's First and only Tech Redevelopment Platform gets your Redevelopment done efficiently and faster by:
                            </p>
                            <p>
                                <span className="fw-bold text-333333">1. Getting everyone on single Platform</span>
                            </p>
                            <p>
                                <span className="fw-bold text-333333">2. Defining clear process at palm of your hand</span>
                            </p>
                            <p>
                                <span className="fw-bold text-333333">3. Getting verified Professionals</span>
                            </p>
                            <p>
                                <span className="fw-bold text-333333">4. Getting Feasibility checked at 3 levels</span>
                            </p>
                            <p>
                                <span className="fw-bold text-333333">5. Getting Paperwork and Area statements compiled</span>
                            </p>
                            <p>
                                <span className="fw-bold text-333333">6. Getting efficient Bidding Parameters</span>
                            </p>
                            <p>
                                <span className="fw-bold text-333333">7. End-to-End service provision with Agreements</span>
                            </p>
                            <div className="d-flex justify-content-center justify-content-lg-start mb-4 mb-lg-3 mt-lg-2">
                                <button
                                    type="button"
                                    className="btn btn-purple-custom px-5"
                                    onClick={() => navigate(AdminRoutes?.CommunityRegister)}
                                >
                                    Register now
                                </button>
                            </div>
                        </div>
                    </div>
                    <div
                        className="col-12 col-md-6 pb-3 px-xl-5 pb-lg-5 order-1 order-md-2"
                    >
                        <input
                            type="image"
                            src={apartment}
                            className="img img-fluid rounded-40"
                            alt="image"
                            srcSet=""
                        />
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Livelife;