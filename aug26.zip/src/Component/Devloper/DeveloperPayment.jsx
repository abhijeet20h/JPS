import React from 'react';
import Layout from '../Layout/Layout';
import { Swiper, SwiperSlide } from "swiper/react";
import { Pagination, Navigation } from "swiper";
import DrLogo from '../../assets/images/drfavicon.png'
import ZohoLogo from '../../assets/images/zoho.png'
import admin1 from '../../assets/images/Placeholder-image.png'
import admin2 from '../../assets/images/Placeholder-image.png'
import admin3 from '../../assets/images/Placeholder-image.png'

const DeveloperPayment = () => {
    return (
        <Layout>
            <div id="login-section" className="container-fluid margin-top-first-container-large">
                <div className="container-lg py-4 py-lg-5">

                    <div className="row g-3 g-lg-5">

                        <div className="col-12 offset-md-2 col-md-8 offset-lg-3 col-lg-6 px-lg-5">
                            <h2 className="text-center text-lg-center mb-2 text-purple">Welcome to <br></br> <strong>Dreams redeveloped</strong> <br></br> Community</h2>
                            <hr className="hr-custom-two mx-auto mb-4 text-center text-lg-center"></hr>
                            <p className="fst-italic fw-normal text-16 text-purple text-center text-lg-start">You are just a step away from being the member of the developer community.</p>
                            {/* <div className="swipper-container-custom SocietyDashboardSwiperContainer">
                                    <Swiper
                                        spaceBetween={10}
                                        slidesPerView={3}
                                        navigation={{
                                            nextEl: ".swiper-button-next",
                                            prevEl: ".swiper-button-prev",
                                        }}
                                        breakpoints={{

                                            300: {
                                                slidesPerView: 2,
                                                slidesPerGroup: 1,
                                                spaceBetweenSlides: 50,
                                            },
                                            860: {
                                                slidesPerView: 2,
                                                slidesPerGroup: 1,
                                                spaceBetweenSlides: 50,
                                            },
                                            990: {
                                                slidesPerView: 3,
                                                slidesPerGroup: 1,
                                                spaceBetweenSlides: 40,
                                            },
                                        }}
                                        className="swiper societyDashboardSwiper"
                                    >
                                        <div className="swiper societyDashboardSwiper">
                                            <div className="swiper-wrapper">
                                                <SwiperSlide>
                                                    <div className="swiper-slide">
                                                        <img src={admin1} alt="image" className="img-fluid society-db-swiper-placeholder overflow-hidden" />
                                                    </div>
                                                </SwiperSlide>
                                                <SwiperSlide>
                                                    <div className="swiper-slide">
                                                        <img src={admin1} alt="image" className="img-fluid society-db-swiper-placeholder overflow-hidden" />
                                                    </div>
                                                </SwiperSlide>
                                                <SwiperSlide>
                                                    <div className="swiper-slide">
                                                        <img src={admin1} alt="image" className="img-fluid society-db-swiper-placeholder overflow-hidden" />
                                                    </div>
                                                </SwiperSlide>
                                                <SwiperSlide>
                                                    <div className="swiper-slide">
                                                        <img src={admin1} alt="image" className="img-fluid society-db-swiper-placeholder overflow-hidden" />
                                                    </div>
                                                </SwiperSlide>
                                                <SwiperSlide>
                                                    <div className="swiper-slide">
                                                        <img src={admin1} alt="image" className="img-fluid society-db-swiper-placeholder overflow-hidden" />
                                                    </div>
                                                </SwiperSlide>

                                            </div>
                                            <div className="swiper-pagination"></div>
                                        </div>
                                    </Swiper>
                                </div> */}
                            <div className="card choose-career-card p-3 pt-4 pb-4">
                                <h2 className="text-center text-lg-left text-purple fw-bold mb-3">
                                    Why choose us?
                                </h2>
                                <p className="text-333333">
                                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                                </p>
                                <p>
                                    <i className="fa fa-check text-orange me-1" aria-hidden="true"></i><span className="fw-bold text-333333">Redevelopment made easy at a reasonable price</span>
                                </p>
                                <p>
                                    <i className="fa fa-check text-orange me-1" aria-hidden="true"></i><span className="fw-bold text-333333">Access to authentic vendors</span>
                                </p>
                                <div
                                    className="d-flex justify-content-center mb-4 mb-lg-3 mt-lg-2">
                                    <button type="button" className="btn btn-orange-custom px-5 ">
                                        Pay Now
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </Layout>
    )
}

export default DeveloperPayment