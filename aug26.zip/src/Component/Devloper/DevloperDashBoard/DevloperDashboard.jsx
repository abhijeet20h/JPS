import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate } from "react-router-dom";
import Layout from '../../Layout/Layout';
import AdminRoutes from '../../../App/Route/RouteDetails';
import PaymentModal from '../../Shared/Modal/PaymentModal';
import baseApi from '../../../environment/Config';

const DevloperDashboard = () => {
    const navigate = useNavigate();
    const [paymentMethod, setPaymentMethod] = useState('')
    const [nextclicked, setNextClicked] = useState(false)
    const userData = JSON.parse(localStorage.getItem('drvalid'));
    const amount = JSON.parse(localStorage.getItem('drDevloperAmount'));

    const handlePaymentModal = () => {
        window.$('#popup-directing-to-razorpay').modal('show')
    }

    useEffect(() => {
        if (nextclicked && paymentMethod === 'Online') {
            console.log("online", paymentMethod)
            setNextClicked(false)
            handleRezorpay()
            window.$('#popup-directing-to-razorpay').modal('hide')
        } else if (nextclicked && paymentMethod === 'Offline') {
            console.log("offline", paymentMethod)
            setNextClicked(false)
            window.$('#popup-directing-to-razorpay').modal('hide')
        }
    }, [nextclicked])


    //redirect to rezorpay
    const handleRezorpay = () => {
        // var data = JSON.stringify({
        //     "amount": 1000,
        //     "currency": "INR",
        //     "accept_partial": true,
        //     "first_min_partial_amount": 100,
        //     "expire_by": 1691097057,
        //     "description": "Payment for policy no #23456",
        //     "customer": {
        //         "name": "satish hande",
        //         "contact": "+918668599969",
        //         "email": "satish.hande@qodequay.in"
        //     },
        //     "notify": {
        //         "sms": true,
        //         "email": true
        //     },
        //     "reminder_enable": true,
        //     "notes": {
        //         "policy_name": "Jeevan Bima"
        //     },
        //     "callback_url": "http://arqosh.qodequay.com:3001/",
        //     "callback_method": "get"
        // });

        // var config = {
        //     method: 'post',
        //     url: 'https://api.razorpay.com/v1/payment_links',
        //     headers: {
        //         'Authorization': 'Basic cnpwX3Rlc3RfYndXbFNyakp1anhSTFo6WnBMVDJHa2pxRWcxVGZGOWNpYWFYVUQ1',
        //         'Content-Type': 'application/json'
        //     },
        //     data: data
        // };

        // axios(config)
        //     .then(function (response) {
        //         console.log(JSON.stringify(response.data));
        //     })
        //     .catch(function (error) {
        //         console.log(error);
        //     });

        var myHeaders = new Headers();
        myHeaders.append("Authorization", "Basic cnpwX3Rlc3RfYndXbFNyakp1anhSTFo6WnBMVDJHa2pxRWcxVGZGOWNpYWFYVUQ1");
        myHeaders.append("Content-Type", "application/json");
        var raw = JSON.stringify({
            "amount": 1000,
            "currency": "INR",
            "accept_partial": true,
            "first_min_partial_amount": 100,
            "expire_by": 1691097057,
            "description": "Payment for policy no #23456",
            "customer": {
                "name": "satish hande",
                "contact": "+918668599969",
                "email": "satish.hande@qodequay.in"
            },
            "notify": {
                "sms": true,
                "email": true
            },
            "reminder_enable": true,
            "notes": {
                "policy_name": "Jeevan Bima"
            },
            "callback_url": "http://arqosh.qodequay.com:3001/",
            "callback_method": "get"
        });

        var requestOptions = {
            method: 'POST',
            headers: myHeaders,
            body: raw,
            redirect: 'follow'
        };

        fetch("https://api.razorpay.com/v1/payment_links", requestOptions)
            .then(response => response.text())
            .then(result => console.log(result))
            .catch(error => console.log('error', error));

    }


    return (
        <Layout>
            <div className="modal fade" id="popup-directing-to-razorpay" tabIndex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <PaymentModal setPaymentMethod={setPaymentMethod} setNextClicked={setNextClicked} />
            </div>
            <div className="container-fluid margin-top-first-container-small bg-white">
                <div className="container-lg py-4 py-lg-5">
                    <div className="row">
                        <div className="col-12 mb-5">
                            <div className="custom-id-card-01 d-inline-flex flex-row align-items-center mx-auto">
                                <img src={userData?.company_logo} alt="image" className='me-2 developer-dashboard-profile-image' />
                                <div className="building-text d-flex flex-column cursor-pointer" onClick={() => navigate(AdminRoutes.DeveloperProfileDetails)}>
                                    <p className="mb-0 text-purple fw-500">Welcome</p>
                                    <p className="mb-0 text-purple fw-600 text-16"> Developer</p>
                                </div>
                            </div>
                        </div>
                        {userData.is_paid === 0 ?

                            <div className='col-12 text-center mb-3'>
                                <button className='btn btn-orange-custom' onClick={() => handlePaymentModal()}>Pay Now</button>
                            </div>
                            :
                            <div className='col-12 text-center'>
                                <button className='btn btn-orange-custom' onClick={() => navigate(AdminRoutes.DeveloperProfile)}>Complete Profile</button>
                            </div>
                        }
                        <div className='col-12 text-center'>
                            <button className='btn btn-orange-custom' onClick={() => navigate(AdminRoutes.DeveloperProfile)}>Complete Profile</button>
                        </div>
                    </div>
                </div>
            </div>
        </Layout >
    )
}


export default DevloperDashboard