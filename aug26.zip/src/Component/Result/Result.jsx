import React from 'react'
import Layout from '../Layout/Layout'
import Faq from '../Shared/Faq/Faq'
import { useNavigate } from "react-router-dom";
import AdminRoutes from '../../App/Route/RouteDetails';

const Result = () => {
    const navigate = useNavigate();
    return (
        <Layout>
            <div className="margin-top-first-container-small">
                <div className="container-lg p-4 py-lg-4">
                    <h2 className="text-center text-lg-left mb-2 mb-lg-4 text-green">Congratulations!</h2>
                    <p className="fst-italic fw-normal text-16 text-purple mb-0 text-center text-lg-left">Here’s the first step towards the life of your
                        dreams…</p>
                </div>
                <div id="congratulations-page-section" className="congratulations-page-section container-fluid bg-green">
                    <div className="container-lg py-4 py-lg-5">


                        <div className="row">
                            <div className="col-12 mb-3 mb-lg-5">
                                <div className="custom-id-card-01 d-flex flex-row align-items-center mx-auto justify-content-center justify-content-lg-start">
                                    <div className="building-icon mr-3">
                                        <i className="fa fa-building text-green" aria-hidden="true"></i>
                                    </div>
                                    <div className="building-text d-flex flex-column">
                                        <p className="mb-0 text-white">Development</p>
                                        <h2 className="mb-0 text-white">Saleable</h2>
                                        <hr className="hr-custom-one m-0"></hr>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="row row-cols-md-3">
                            <div className="col-12 col-sm-6 col-md col-lg-4 mb-0 py-2">
                                <div className="custom-counter-card card h-100 mx-0">
                                    <div className="card-body">
                                        <h5 className="card-title text-white text-left">2.25</h5>
                                        <hr></hr>
                                        <p className="card-text text-white">FSI factor</p>
                                    </div>
                                </div>
                            </div>

                            <div className="col-12 col-sm-6 col-md col-lg-4 mb-0 py-2">
                                <div className="custom-counter-card card h-100 mx-0">
                                    <div className="card-body">
                                        <h5 className="card-title text-white text-left">162.58</h5>
                                        <hr></hr>
                                        <p className="card-text text-white">Saleable (Sqr. Mtr)</p>
                                    </div>
                                </div>
                            </div>

                            <div className="col-12 col-sm-6 col-md col-lg-4 mb-0 py-2">
                                <div className="custom-counter-card card h-100 mx-0">
                                    <div className="card-body">
                                        <h5 className="card-title text-white text-left">133.26</h5>
                                        <hr></hr>
                                        <p className="card-text text-white">Carpet (Sqr. Mtrs)</p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="row">

                            <div className="col-12 mt-2 text-center">
                                <p className="text-white text-decoration-underline">Retake Feasibility</p>
                                <p className="text-white">Great! Your society’s redevelopment feasibility looks good. To save this data register now.
                                </p>
                            </div>

                            <div className="col-12">
                                <div className="d-flex flex-column justify-content-center align-items-center mb-4 mb-lg-3 mt-lg-2">
                                    <button type="button" className="btn btn-light px-5 text-purple" onClick={() => navigate(AdminRoutes?.CommunityRegister)}>Register Now !</button>
                                </div>
                            </div>


                        </div>

                    </div>
                </div>
            </div>
            <Faq />
        </Layout>
    )
}

export default Result