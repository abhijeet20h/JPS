import React from 'react';
import drlogo from '../../../assets/images/DR-logo.png'
import instagramLogo from '../../../assets/images/instagram-logo.png';
import facebookLogo from '../../../assets/images/facebook-logo.png';
import linkedinLogo from '../../../assets/images/linkedin-logo.png';
import AdminRoutes from '../../../App/Route/RouteDetails';
import { useNavigate } from "react-router-dom";

const Footer = () => {
    const navigate = useNavigate();
    return (
        <div id="footer-section" className="footer-section container-fluid py-5">
            <div className="container-lg py-3 py-lg-5">
                <div className="row">
                    <div className="col-12 col-lg-4 mb-3 mb-lg-0">
                        <div>
                            <input
                                type="image"
                                src={drlogo}
                                className="dr-logo"
                                alt="image"
                                srcSet=""
                            />
                        </div>
                    </div>
                    <div className="col-12 col-lg-8 mb-3 mb-lg-0">
                    <div className='row'>
                    <div className='col-12'>
                    <h5>Quick Links</h5>
                        <hr className="hr-custom-one mb-3" />
                    </div>
                    <div className='col-12 col-lg-6'>
                    <ul className="quick-links mb-0">
                            <li>
                                <span onClick={() => navigate(AdminRoutes.DashBoard)} className="text-decoration-none text-white cursor-pointer">Home</span>
                            </li>
                            <li>
                                <span onClick={() => navigate(AdminRoutes.DevloperLogin)} className="text-decoration-none text-white cursor-pointer">
                                    Developers</span>
                            </li>
                            <li><a href="#" className="text-decoration-none text-white">About Us</a></li>
                            <li><a href="#" className="text-decoration-none text-white">Careers</a></li>
                            <li><a href="tel:+919130553592" className="text-decoration-none text-white">Contact Us</a></li>
                            <li><a href="mailto: dreamsredevelopedops@gmail.com" className="text-decoration-none text-white">Mail</a></li>
                        </ul>
                    </div>
                    <div className='col-12 col-lg-6'>
                    <ul className="quick-links mb-3">
                            <li><span onClick={() => navigate(AdminRoutes.PrivacyPolicy)} className="text-decoration-none text-white cursor-pointer">Privacy policy</span></li>
                            <li><span onClick={() => navigate(AdminRoutes.TermsAndCondistions)} className="text-decoration-none text-white cursor-pointer">Terms & conditions</span></li>
                        </ul>
                        <div className="d-flex flex-row mb-3" style={{paddingLeft: "2rem"}}>
                            <a href="https://www.instagram.com/dreamsredeveloped/?hl=en" className='text-decoration-none' target="_blank"><img src={instagramLogo} className="footer-logos"/></a>
                            <a href="https://www.facebook.com/Dreamsredeveloped-104813075248797" className='text-decoration-none' target="_blank"><img src={facebookLogo}  className="footer-logos"/></a>
                            <a href='https://www.linkedin.com/company/dreamsredeveloped/' target=" className='text-decoration-none'_blank"> <img src={linkedinLogo}  className="footer-logos"/></a>
                        </div>
                    </div>
                    </div>
                    </div>
                        
                        {/*
                       <h5 className="d-none d-lg-block mt-4">Stay connected to DR</h5>
                        <hr className="hr-custom-one mb-3 d-none d-lg-block" />
                        <h5 className="d-block d-lg-none">Co- Operate Newsletter</h5>
                        <hr className="hr-custom-one mb-3 d-block d-lg-none" />
                        <p className="d-block d-lg-none">
                            Get regular Co-operate community updates by signing up to our
                            newsletter.
                        </p>
                        <div className="input-group mb-3">
                            <input
                                type="text"
                                className="form-control email-input-one"
                                placeholder="Enter Your E-mail Address"
                                aria-label="Enter Your E-mail Address"
                                aria-describedby="button-footer-email"
                            />
                            <button
                                className="btn btn-outline-secondary d-none d-lg-block button-footer-email"
                                type="button">
                                Stay updated
                            </button>
                        </div>
                        <button className="btn px-5 btn-outline-secondary d-block d-lg-none float-end button-footer-email" type="button">
                            Submit
                        </button>
                    */}
                        
                </div>
            </div>
        </div>
    )
}

export default Footer