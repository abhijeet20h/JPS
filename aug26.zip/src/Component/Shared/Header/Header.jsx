import React from 'react'
import drlogo from '../../../assets/images/DR-logo.png'
import AdminRoutes from '../../../App/Route/RouteDetails';
import { useNavigate, useLocation } from "react-router-dom";


const Header = () => {
    const navigate = useNavigate();
    const location = useLocation();

    const userInfo = JSON.parse(localStorage.getItem('drvalid'));

    return (
        <>
            {/*nav head*/}
            <div className="navbar-section navbar navbar-expand-lg fixed-top">
                <div className="container-lg px-4 px-lg-0 py-2 py-lg-0">
                    <span onClick={() => navigate(-1)} className={location.pathname === AdminRoutes.DashBoard ? 'navbar-brand d-none d-lg-none align-items-center mb-0 my-lg-2 text-dark text-decoration-none cursor-pointer' : 'navbar-brand d-flex d-lg-none align-items-center mb-0 my-lg-2 text-dark text-decoration-none cursor-pointer'}>
                        <i className="fa fa-chevron-left text-white" aria-hidden="true"></i>
                    </span>
                    <input
                        type="image"
                        src={drlogo}
                        className={location.pathname === AdminRoutes.DashBoard ? "dr-logo d-lg-flex cursor-pointer" : "dr-logo d-none d-lg-flex cursor-pointer"}
                        alt="photo"
                        srcSet=""
                        onClick={() => navigate(AdminRoutes?.DashBoard)}
                    />
                    {location.pathname === AdminRoutes.DashBoard ? null : <span className="d-inline-block d-block d-lg-none">Form Title</span>}
                    <div className="d-flex d-lg-none">
                        <button
                            className="navbar-toggler me-3"
                            type="button"
                            data-bs-toggle="collapse"
                            data-bs-target="#navbarText"
                            aria-controls="navbarText"
                            aria-expanded="false"
                            aria-label="Toggle navigation"
                        >
                            <i className="fa fa-bars text-white" aria-hidden="true"></i>
                        </button>
                        <i className="fa fa-user-circle-o profile-menu-user-icon-lg" aria-hidden="true" type="button" data-bs-toggle="offcanvas" data-backdrop="static" data-keyboard="false" data-bs-target=".custom-profile-logout-menu" aria-controls="offcanvasRight"></i>

                    </div>
                    <div
                        className="collapse navbar-collapse justify-content-end"
                        id="navbarText"
                    >
                        <ul className="navbar-nav mb-2 mb-lg-0">
                            <li className="nav-item">
                                <span className="nav-link text-white px-lg-3 cursor-pointer" onClick={() => navigate(AdminRoutes?.DashBoard)}>Home</span>
                            </li>
                            <li className="nav-item">
                                <span className="nav-link text-white px-lg-3 cursor-pointer" onClick={() => navigate(AdminRoutes?.AboutUs)}>About</span>
                            </li>
                            <li className="nav-item">
                                <span className="nav-link text-white px-lg-3 cursor-pointer" onClick={() => navigate(AdminRoutes?.Blogs)}>Blogs</span>
                            </li>
                            <li className="nav-item">
                                <span className="nav-link text-white px-lg-3 cursor-pointer" onClick={() => navigate(AdminRoutes?.DashBoardFeature)}>Features</span>
                            </li>
                            <li className="nav-item">
                                <span className="nav-link text-white px-lg-3 cursor-pointer" onClick={() => navigate(AdminRoutes?.DashBoardService)}>Choose A Service</span>
                            </li>
                            <li className="nav-item">
                                <span className="nav-link text-white px-lg-3 cursor-pointer" onClick={() => navigate(AdminRoutes?.EventsPage)}>Events</span>
                            </li>
                        </ul>
                            <div className="text-end px-lg-3">
                                <button type="button" className="btn btn-orange-custom rounded-15" onClick={() => navigate(AdminRoutes?.CommunityRegister)}>
                                    Register/Login
                                </button>
                            </div>
                            <div className="ms-3 d-none d-lg-flex">
                                <i className="fa fa-user-circle-o profile-menu-user-icon-lg cursor-pointer" aria-hidden="true" type="button" data-bs-toggle="offcanvas" data-bs-target=".custom-profile-logout-menu" data-backdrop="static" data-keyboard="false" aria-controls="offcanvasRight"></i>
                            </div>
                    </div>
                </div>
            </div>

        </>
    )
}

export default Header