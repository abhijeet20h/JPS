import React from 'react';


const PaymentModal = (props) => {

    const handleMethod = (e) => {
        props.setPaymentMethod(e.target.value)
    }

    const handleNext = () => {
        props.setNextClicked(true)

    }

    return (
        <div className="modal-dialog modal-dialog-centered">
            <div className="modal-content bg-white border-white">
                <div className="modal-header border-bottom-0 justify-content-end">
                    <i className="fa fa-1x fa-times-circle cursor-pointer text-secondary" aria-hidden="true" data-bs-dismiss="modal" aria-label="Close"></i>
                </div>
                <div className="modal-body text-center text-purple">
                    <h3 className="mb-4 text-center text-purple">Please select<br></br>Payment Mode</h3>
                    <div className="card custom-form-card p-3 w-50 mx-auto">
                        <div className="form-check custom-form-check">
                            <input className="form-check-input" type="radio" name="exampleRadios" id="exampleRadios1"
                                value="Online" onChange={e => handleMethod(e)} />
                            <label className="form-check-label fw-500" htmlFor="exampleRadios1"> Online (razorpay) </label>
                        </div>
                        <div className="form-check custom-form-check">
                            <input className="form-check-input" type="radio" name="exampleRadios" id="exampleRadios2"
                                value="Offline" onChange={e => handleMethod(e)} />
                            <label className="form-check-label fw-500" htmlFor="exampleRadios2"> Offline (cheque)
                            </label>
                        </div>
                    </div>
                    <br></br>
                    <div className="text-center">
                        <button className="btn btn-orange-custom" onClick={e => handleNext()}>Next</button>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default PaymentModal;