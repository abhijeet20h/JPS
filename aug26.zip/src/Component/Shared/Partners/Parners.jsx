import React from 'react'
import { Swiper, SwiperSlide } from "swiper/react";
import { Pagination, Navigation } from "swiper";
import Lawyered from "../../../assets/images/Lawyered.svg"
import Zohofin from "../../../assets/images/zohofinance.png"
import CcCo from "../../../assets/images/CCco.svg"

const Parners = () => {
    return (
        <div id="our-partners-section" className="testimonials-section our-partners-section container-fluid d-none d-lg-block">
            <div className="container-lg py-4 py-lg-5">
                <h2 className="text-center text-white mb-4 mb-lg-5 fw-bold pt-4">
                    Our Partners
                </h2>
                <div className="swipper-container-custom mb-5">
                    {/* Swiper */}
                    <Swiper
                        pagination={{
                            type: "fraction"
                        }}
                        slidesPerView={3}
                        navigation={true}
                        modules={[Pagination, Navigation]}
                        onSlideChange={() => console.log('slide change')}
                        onSwiper={(swiper) => console.log(swiper)}
                        className="partnersSwiper"
                    >
                        <SwiperSlide>
                            <div className="swiper-slide">
                                <div
                                    className="d-flex flex-column align-items-center item-className-custom"
                                >
                                    <div className="testimonial-round-image-placeholder mb-4 overflow-hidden">
                                        <input type="image" src={Lawyered} alt="image" srcSet="" />
                                    </div>
                                    <h5 className="mb-3">Lawyered</h5>
                                    <p>
                                        Finding a good lawyer is hard, so we made it better, easier and faster.
                                    </p>
                                </div>
                            </div>
                        </SwiperSlide>
                        <SwiperSlide>
                            <div className="swiper-slide">
                                <div
                                    className="d-flex flex-column align-items-center item-className-custom"
                                >
                                    <div className="testimonial-round-image-placeholder mb-4 overflow-hidden">
                                        <input type="image" src={Zohofin} alt="image" srcSet="" />
                                    </div>
                                    <h5 className="mb-3">Zoho Finance</h5>
                                    <p>
                                        Run your entire business with 45+ integrated applications
                                    </p>
                                </div>
                            </div>
                        </SwiperSlide>
                        <SwiperSlide>
                            <div className="swiper-slide">
                                <div
                                    className="d-flex flex-column align-items-center item-className-custom"
                                >
                                    <div className="testimonial-round-image-placeholder mb-4 overflow-hidden">
                                        <input type="image" src={CcCo} alt="image" srcSet="" />
                                    </div>
                                    <h5 className="mb-3">CC&Co.</h5>
                                    <p>
                                        Best CoWorking Space in Pune

                                    </p>
                                </div>
                            </div>
                        </SwiperSlide>
                    </Swiper>
                </div>
            </div>
        </div>
    )
}

export default Parners