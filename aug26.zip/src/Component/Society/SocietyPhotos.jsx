import React, { useState, useEffect } from 'react';
import Layout from '../Layout/Layout';
import baseApi from '../../environment/Config';
import AdminRoutes from '../../App/Route/RouteDetails';
import { useNavigate } from "react-router-dom";
import axios from 'axios';

const SocietyPhotos = () => {
    const navigate = useNavigate();
    const [CoverImg, setCoverImg] = useState("");
    const [SocietyImg1, setSocietyImg1] = useState("");
    const [SocietyImg2, setSocietyImg2] = useState("");
    const [SocietyImg3, setSocietyImg3] = useState("");
    const [SocietyImg4, setSocietyImg4] = useState("");
    const [Photos, setPhotos] = useState(["", "", "", "", ""]);
    const userInfo = JSON.parse(localStorage.getItem('drvalid'));
    const [spinner, setSpinner] = useState(false);


    useEffect(() => {
        window.scrollTo(0, 0)
    }, [])


    // uploade image
    const UploadSocietyImage = (Value, e) => {
        // for the spinner
        if (Value === 1) {
            setSpinner("cover")
        }
        if (Value === 2) {
            setSpinner("img1")
        }
        if (Value === 3) {
            setSpinner("img2")
        }
        if (Value === 4) {
            setSpinner("img3")
        }
        if (Value === 5) {
            setSpinner("img4")
        }
        var formdata = new FormData();
        formdata.append("file", e.target.files[0]);

        var requestOptions = {
            method: 'POST',
            body: formdata,
            redirect: 'follow'
        };

        fetch(`${baseApi.baseUrl}fileupload`, requestOptions)
            .then(response => response.text())
            .then(result => setImage(JSON.parse(result).file_path, Value))
            .catch(error => setSpinner(false));
    };

    // set image values
    const setImage = (imagePath, Value) => {
        if (Value === 1) {
            setCoverImg(imagePath)
            Photos[0] = imagePath
        }
        if (Value === 2) {
            setSocietyImg1(imagePath)
            Photos[1] = imagePath
        }
        if (Value === 3) {
            Photos[2] = imagePath
            setSocietyImg2(imagePath)
        }
        if (Value === 4) {
            Photos[3] = imagePath
            setSocietyImg3(imagePath)
        }
        if (Value === 5) {
            Photos[4] = imagePath
            setSocietyImg4(imagePath)
        }
        setSpinner(false)
    }

    const handlePhoto = async (e) => {
        e.preventDefault()
        try {
            var data = JSON.stringify({
                "no_of_buildings": 0,
                "no_of_floors": 0,
                "no_of_flats": 0,
                "garage": 0,
                "outhouse": 0,
                "shopes": 0,
                "offices": 0,
                "society_name": userInfo?.data?.society_name,
                "location": userInfo?.data?.location,
                "address": userInfo?.data?.address,
                "choose_property": "Residential",
                "propery_type": "Society/ Apartment",
                "gross_plot_area": userInfo?.data?.gross_plot_area,
                "name": userInfo?.data?.full_name,
                "appointment_letter": userInfo?.data?.appointment_letter,
                "property_type": "Apartment",
                "society_photos": Photos,
                "email": userInfo?.data?.email,
                "mobile": userInfo?.data?.mobile,
                "company_name": "",
                "entity_name": "",
                "building_info": {},
                "Website": "",
                "service_year": 0,
                "redevelopment_year": 0,
                "expertise": "",
                "company_logo": "",
                "Payment_Link_Id": "",
                "balance_sheet": "",
                "income_tax_return": "",
                "cibil_score": "",
                "partners_info": [],
                "roles": 1
            });

            var config = {
                method: 'put',
                url: `${baseApi.baseUrl}user/updateuser/${userInfo._id}`,
                headers: {
                    'Content-Type': 'application/json'
                },
                data: data
            };

            await axios(config)
                .then(function (response) {
                    if (response.data.message === 'Data successfully updated...') {
                        localStorage.setItem("drvalid", JSON.stringify(response.data))
                        navigate(AdminRoutes.SocietyBuildingDetails);
                    }
                })
        } catch (err) {
            console.log(err)
        }
    }

    return (
        <Layout>
            <div id="society-photos-page-section" className="society-photos-page-section container-fluid margin-top-first-container-small">
                <div className="container-lg py-4 py-lg-5">
                    <div className="row">
                        <div className="col-12 mb-3">
                            <div className="d-flex justify-content-between flex-row mb-2">
                                <div
                                    className="custom-id-card-01 text-purple d-flex flex-row align-items-center justify-content-start justify-content-lg-start">
                                    <div className="building-icon mr-3">
                                        <i className="fa fa-building" aria-hidden="true"></i>
                                    </div>
                                    <div className="building-text d-flex flex-column">
                                        <p className="mb-0 fw-600 text-16">Society Details</p>
                                    </div>
                                </div>
                            </div>
                            <div className="progress mb-4 rounded-20">
                                <div className="progress-bar rounded-20 bg-orange" role="progressbar" style={{ width: "50%" }} aria-valuenow="75"
                                    aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                    </div>
                    <div className="row mb-3">
                        <div className="col-12">
                            <h4 className="text-purple">Society Photos</h4>
                            <p className="text-purple">Upload photos of your society for the website.</p>
                            {/*        <button className="btn btn-orange-custom">Upload</button>*/}
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-12">
                            <div className="row g-3 row-cols-1 mb-3">
                                <div className="col-12">
                                    <div className="custom-buiding-details-card bg-light p-0 h-100">
                                        {spinner === 'cover' ?
                                            <>
                                                <div className="d-flex flex-row photo-placeholder-div-cover justify-content-center align-items-center">
                                                    <div className="spinner-grow text-orange" role="status">
                                                        <span className="sr-only">Loading...</span>
                                                    </div>
                                                </div>
                                            </>
                                            :
                                            <>
                                                {!CoverImg
                                                    ?
                                                    <div className="d-flex flex-row photo-placeholder-div-cover" onChange={(e) => UploadSocietyImage(1, e)}>
                                                        <i aria-hidden="true" className='fa fa-upload society-photo-upload-icon'></i>
                                                        <div className="d-flex flex-row photo-upload-subheader justify-content-between position-absolute top-0 start-0">
                                                            <span className="ms-3">Cover Photo</span>
                                                            <div className="image-upload-wrapper">
                                                                <label htmlFor="file-input1" className="photoicon">
                                                                    <i className="fa fa-plus-circle cursor-pointer" aria-hidden="true"></i>
                                                                </label>
                                                                <input id="file-input1" type="file" className="d-none" accept="image/png, image/gif, image/jpeg" name="CoverImg" onChange={(e) => UploadSocietyImage(1, e)} />
                                                            </div>
                                                        </div>
                                                    </div>

                                                    :
                                                    <div className="d-flex flex-row photo-placeholder-div-cover">
                                                        <div className="d-flex flex-row photo-upload-subheader justify-content-between position-absolute top-0 start-0">
                                                            <span className="ms-3">Cover Photo</span>
                                                            <div className="image-upload-wrapper">
                                                                <label htmlFor="file-input1" className="photoicon">
                                                                    <i className="fa fa-plus-circle cursor-pointer" aria-hidden="true"></i>
                                                                </label>
                                                                <input id="file-input1" type="file" className="d-none" accept="image/png, image/gif, image/jpeg" name='SocietyImg4' onChange={(e) => UploadSocietyImage(1, e)} />
                                                            </div>
                                                        </div>
                                                        <div className='SocietyPhotosBgDiv' style={{ backgroundImage: `url(${CoverImg})` }}></div>
                                                    </div>
                                                }</>
                                        }
                                    </div>
                                </div>
                            </div>
                            <div className="row g-3 row-cols-2 row-cols-md-4">
                                <div className="col-6 col-sm-6 ">
                                    <div className="custom-buiding-details-card bg-light h-100">
                                        {spinner === 'img1' ?
                                            <>
                                                <div className="d-flex flex-row photo-placeholder-div justify-content-center align-items-center">
                                                    <div className="spinner-grow text-orange" role="status">
                                                        <span className="sr-only">Loading...</span>
                                                    </div>
                                                </div>

                                            </>
                                            :
                                            <>
                                                {!SocietyImg1
                                                    ?
                                                    <div className="d-flex flex-row photo-placeholder-div">
                                                    <i aria-hidden="true" className='fa fa-upload society-photo-upload-icon'></i>  
                                                        <div className="d-flex flex-row photo-upload-subheader justify-content-end position-absolute top-0 start-0">
                                                            <div className="image-upload-wrapper">
                                                                <label htmlFor="file-input2" className="photoicon">
                                                                    <i className="fa fa-plus-circle cursor-pointer" aria-hidden="true"></i>
                                                                </label>
                                                                <input id="file-input2" type="file" className="d-none" accept="image/png, image/gif, image/jpeg" name='SocietyImg1' onChange={(e) => UploadSocietyImage(2, e)} />
                                                            </div>
                                                        </div>
                                                    </div>
                                                    :
                                                    <div className="d-flex flex-row photo-placeholder-div">
                                                        <div className="d-flex flex-row photo-upload-subheader justify-content-end position-absolute top-0 start-0">
                                                            <div className="image-upload-wrapper">
                                                                <label htmlFor="file-input2" className="photoicon">
                                                                    <i className="fa fa-plus-circle cursor-pointer" aria-hidden="true"></i>
                                                                </label>
                                                                <input id="file-input2" type="file" className="d-none" accept="image/png, image/gif, image/jpeg" name='SocietyImg4' onChange={(e) => UploadSocietyImage(2, e)} />
                                                            </div>
                                                        </div>
                                                        <div className='SocietyPhotosBgDiv' style={{ backgroundImage: `url(${SocietyImg1})` }}></div>
                                                    </div>
                                                }
                                            </>}
                                    </div>
                                </div>
                                <div className="col-6 col-sm-6 ">
                                    <div className="custom-buiding-details-card bg-light h-100">
                                        {spinner === 'img2' ?
                                            <>
                                                <div className="d-flex flex-row photo-placeholder-div justify-content-center align-items-center">
                                                    <div className="spinner-grow text-orange" role="status">
                                                        <span className="sr-only">Loading...</span>
                                                    </div>
                                                </div>

                                            </>
                                            :
                                            <>
                                                {!SocietyImg2
                                                    ?
                                                    <div className="d-flex flex-row photo-placeholder-div">
                                                    <i aria-hidden="true" className='fa fa-upload society-photo-upload-icon'></i>     
                                                    <div className="d-flex flex-row photo-upload-subheader justify-content-end position-absolute top-0 start-0">
                                                            <div className="image-upload-wrapper">
                                                                <label htmlFor="file-input3" className="photoicon">
                                                                    <i className="fa fa-plus-circle cursor-pointer" aria-hidden="true"></i>
                                                                </label>
                                                                <input id="file-input3" type="file" className="d-none" accept="image/png, image/gif, image/jpeg" name='SocietyImg2' onChange={(e) => UploadSocietyImage(3, e)} />
                                                            </div>
                                                        </div>
                                                    </div>
                                                    :
                                                    <div className="d-flex flex-row photo-placeholder-div">
                                                        <div className="d-flex flex-row photo-upload-subheader justify-content-end position-absolute top-0 start-0">
                                                            <div className="image-upload-wrapper">
                                                                <label htmlFor="file-input3" className="photoicon">
                                                                    <i className="fa fa-plus-circle cursor-pointer" aria-hidden="true"></i>
                                                                </label>
                                                                <input id="file-input3" type="file" className="d-none" accept="image/png, image/gif, image/jpeg" name='SocietyImg4' onChange={(e) => UploadSocietyImage(3, e)} />
                                                            </div>
                                                        </div>
                                                        <div className='SocietyPhotosBgDiv' style={{ backgroundImage: `url(${SocietyImg2})` }}></div>
                                                    </div>
                                                }
                                            </>
                                        }
                                    </div>
                                </div>
                                <div className="col-6 col-sm-6 ">
                                    <div className="custom-buiding-details-card bg-light h-100">
                                        {spinner === 'img3' ?
                                            <>
                                                <div className="d-flex flex-row photo-placeholder-div justify-content-center align-items-center">
                                                    <div className="spinner-grow text-orange" role="status">
                                                        <span className="sr-only">Loading...</span>
                                                    </div>
                                                </div>

                                            </>
                                            :
                                            <>
                                                {!SocietyImg3
                                                    ?
                                                    <div className="d-flex flex-row photo-placeholder-div">
                                                    <i aria-hidden="true" className='fa fa-upload society-photo-upload-icon'></i>     
                                                    <div className="d-flex flex-row photo-upload-subheader justify-content-end position-absolute top-0 start-0">
                                                            <div className="image-upload-wrapper">
                                                                <label htmlFor="file-input4" className="photoicon">
                                                                    <i className="fa fa-plus-circle cursor-pointer" aria-hidden="true"></i>
                                                                </label>
                                                                <input id="file-input4" type="file" className="d-none" accept="image/png, image/gif, image/jpeg" name='SocietyImg3' onChange={(e) => UploadSocietyImage(4, e)} />
                                                            </div>
                                                        </div>
                                                    </div>
                                                    :
                                                    <div className="d-flex flex-row photo-placeholder-div">
                                                        <div className="d-flex flex-row photo-upload-subheader justify-content-end position-absolute top-0 start-0">
                                                            <div className="image-upload-wrapper">
                                                                <label htmlFor="file-input4" className="photoicon">
                                                                    <i className="fa fa-plus-circle cursor-pointer" aria-hidden="true"></i>
                                                                </label>
                                                                <input id="file-input4" type="file" className="d-none" accept="image/png, image/gif, image/jpeg" name='SocietyImg4' onChange={(e) => UploadSocietyImage(4, e)} />
                                                            </div>
                                                        </div>
                                                        <div className='SocietyPhotosBgDiv' style={{ backgroundImage: `url(${SocietyImg3})` }}></div>
                                                    </div>
                                                }
                                            </>
                                        }
                                    </div>
                                </div>
                                <div className="col-6 col-sm-6 ">
                                    <div className="custom-buiding-details-card bg-light h-100">
                                        {spinner === 'img4' ?
                                            <>
                                                <div className="d-flex flex-row photo-placeholder-div justify-content-center align-items-center">
                                                    <div className="spinner-grow text-orange" role="status">
                                                        <span className="sr-only">Loading...</span>
                                                    </div>
                                                </div>

                                            </>
                                            :
                                            <>
                                                {!SocietyImg4
                                                    ?
                                                    <div className="d-flex flex-row photo-placeholder-div">
                                                    <i aria-hidden="true" className='fa fa-upload society-photo-upload-icon'></i>     
                                                    <div className="d-flex flex-row photo-upload-subheader justify-content-end position-absolute top-0 start-0">
                                                            <div className="image-upload-wrapper">
                                                                <label htmlFor="file-input5" className="photoicon">
                                                                    <i className="fa fa-plus-circle cursor-pointer" aria-hidden="true"></i>
                                                                </label>
                                                                <input id="file-input5" type="file" className="d-none" accept="image/png, image/gif, image/jpeg" name='SocietyImg4' onChange={(e) => UploadSocietyImage(5, e)} />
                                                            </div>
                                                        </div>
                                                    </div>
                                                    :
                                                    <div className="d-flex flex-row photo-placeholder-div">
                                                        <div className="d-flex flex-row photo-upload-subheader justify-content-end position-absolute top-0 start-0">
                                                            <div className="image-upload-wrapper">
                                                                <label htmlFor="file-input5" className="photoicon">
                                                                    <i className="fa fa-plus-circle cursor-pointer" aria-hidden="true"></i>
                                                                </label>
                                                                <input id="file-input5" type="file" className="d-none" accept="image/png, image/gif, image/jpeg" name='SocietyImg4' onChange={(e) => UploadSocietyImage(5, e)} />
                                                            </div>
                                                        </div>
                                                        <div className='SocietyPhotosBgDiv' style={{ backgroundImage: `url(${SocietyImg4})` }}></div>
                                                    </div>
                                                }
                                            </>
                                        }
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    {/* <div className="col-8 offset-2 col-lg-4 offset-lg-4 text-center mt-3">
                            <button type="button" className="btn px-5 btn-gray-custom-inverse">Add More Photos + </button>
                        </div> */}


                    <div className="row">
                        <div className="col-12 text-center mt-5 mt-lg-5 mb-4 mb-lg-0">
                            <button className="btn btn-purple-custom px-5" onClick={(e) => handlePhoto(e)}>Next</button>
                        </div>
                    </div>
                </div>
            </div>
        </Layout>
    )
}

export default SocietyPhotos