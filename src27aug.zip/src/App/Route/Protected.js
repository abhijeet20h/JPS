import React from 'react';
import {
    Navigate,
    Outlet
} from 'react-router-dom';

const Protected = ({ redirectPath, children }) => {
    const isAuthenticated = localStorage.getItem("drvalid");

    if (!isAuthenticated) {
        return <Navigate to={redirectPath} replace />;
    }
    return children ? children : <Outlet />
}

export default Protected;