import React from 'react';
import {
    HashRouter,
    Routes,
    Route,
} from "react-router-dom";
import Protected from './Protected';
import AdminRoutes from './RouteDetails';
import DashBoard from '../../Component/DashBoard/DashBoard';
import Blogs from '../../Component/Blogs/Blogs';
import BlogsDetailsOne from '../../Component/Blogs/BlogsDetailsOne';
import BlogsDetailsTwo from '../../Component/Blogs/BlogsDetailsTwo';
import BlogsDetailsThree from '../../Component/Blogs/BlogsDetailsThree';
import BlogsDetailsFour from '../../Component/Blogs/BlogsDetailsFour';
import BlogsDetailsFive from '../../Component/Blogs/BlogsDetailsFive';
import BlogsDetailsSix from '../../Component/Blogs/BlogsDetailsSix';
import BlogsDetailsSeven from '../../Component/Blogs/BlogsDetailsSeven';
import Wizard from "../../Component/Wizard/Wizard";
import Result from '../../Component/Result/Result';
import CommunityRegister from "../../Component/Auth/CommunityRegister/CommunityRegister";
import ChairmanRegister from '../../Component/Auth/Chairman/ChairmanRegister';
import ChairmanLogin from '../../Component/Auth/Chairman/ChairmanLogin';
import ChairmanDashboard from '../../Component/Auth/Chairman/ChairmanDashboard';
import PropertyOwnerLogin from '../../Component/Auth/PropertyOwner/PropertyOwnerLogin';
import PropertyOwnerRegister from '../../Component/Auth/PropertyOwner/PropertyOwnerRegister';
import PropertyOwnerProfile from '../../Component/Auth/PropertyOwner/PropertyOwnerProfile';
import OwnerDashBoard from '../../Component/Owner/OwnerDashBoard';
import DevloperLogin from "../../Component/Auth/Devloper/DevloperLogin";
import DevloperRegister from "../../Component/Auth/Devloper/DevloperRegister";
import DevloperRegisterStepOne from "../../Component/Auth/Devloper/DevloperRegisterStepOne";
import DevloperRegisterStepTwo from '../../Component/Auth/Devloper/DevloperRegisterStepTwo';
import DevloperVerification from '../../Component/Devloper/DevloperVerification';
import DevloperDashboard from '../../Component/Devloper/DevloperDashBoard/DevloperDashboard';
import DevloperRegisterPartner from "../../Component/Devloper/DevloperRegisterPartner/DevloperRegisterPartner";
import DeveloperPayment from "../../Component/Devloper/DeveloperPayment";
import DeveloperProfile from "../../Component/Devloper/DeveloperProfile";
import DeveloperProfileEdit from "../../Component/Devloper/DeveloperProfileEdit";
import DeveloperProfileDetails from '../../Component/Devloper/DeveloperProfileDetails';
import DevloperProfileCompletion from "../../Component/Devloper/DevloperProfileCompletion";
import DeveloperPortfolio from "../../Component/Devloper/DeveloperPortfolio";
import SocietyRegister from '../../Component/Auth/SocietyRegister/SocietyRegister';
import SocietyConfigration from "../../Component/Society/SocietyConfigration";
import SocietyDetails from "../../Component/Society/SocietyDetails";
import SocietyPhotos from "../../Component/Society/SocietyPhotos";
import SocietyBuildingDetails from "../../Component/Society/SocietyBuildingDetails";
import SocietyOverview from "../../Component/Society/SocietyOverview";
import SocietydashBoard from "../../Component/Society/SocietydashBoard";
import WingsDetails from "../../Component/Society/WingsDetails/WingsDetails";
import UnitDetails from "../../Component/Society/UnitDetails/UnitDetails";
import FloorDetails from "../../Component/Society/FloorDetails/FloorDetails";
import OtpVerification from "../../Component/Shared/OtpVerification/OtpVerification";
import OtpVerifictionOwner from "../../Component/Shared/OtpVerification/OtpVerifictionOwner";
import PrivacyPolicy from "../../Component/PrivacyPolicy/PrivacyPolicy";
import TermsAndCondistions from '../../Component/TermsAndCondistions/TermsAndCondistions';
import AboutUs from "../../Component/Aboutus/AboutUs";
import EventsPage from '../../Component/EventsPage/EventsPage';
// import Profile from '../../Component/DashBoard/Profile';
import ChairmanProfile from '../../Component/Auth/Chairman/ChairmanProfile';
import SocietyProfile from '../../Component/Society/SocietyProfile';
import FlatOwnerProfile from '../../Component/Auth/PropertyOwner/FlatOwnerProfile';
import SocietyFlatOwnerView from '../../Component/Society/SocietyFlatOwnerView';

const RouteIndex = () => {
    return (
        <HashRouter >
            <Routes>
                <Route exact path={AdminRoutes.DashBoard} element={<DashBoard />} />
                <Route exact path={AdminRoutes.DashBoardFeature} element={<DashBoard />} />
                <Route exact path={AdminRoutes.DashBoardService} element={<DashBoard />} />
                <Route exact path={AdminRoutes.Wizard} element={<Wizard />} />
                <Route exact path={AdminRoutes.Result} element={<Result />} />

                {/*Auth*/}
                <Route exact path={AdminRoutes.CommunityRegister} element={<CommunityRegister />} />
                <Route exact path={AdminRoutes.DevloperLogin} element={<DevloperLogin />} />
                <Route exact path={AdminRoutes.DevloperRegister} element={<DevloperRegister />} />
                <Route exact path={AdminRoutes.DevloperRegisterStepOne} element={<DevloperRegisterStepOne />} />
                <Route exact path={AdminRoutes.DevloperRegisterStepTwo} element={<DevloperRegisterStepTwo />} />
                <Route exact path={AdminRoutes.SocietyRegister} element={<SocietyRegister />} />
                <Route exact path={AdminRoutes.ChairmanRegister} element={<ChairmanRegister />} />
                <Route exact path={AdminRoutes.ChairmanLogin} element={<ChairmanLogin />} />
                <Route exact path={AdminRoutes.PropertyOwnerLogin} element={<PropertyOwnerLogin />} />
                <Route exact path={AdminRoutes.PropertyOwnerRegister} element={<PropertyOwnerRegister />} />

                {/*Blogs*/} 

                <Route exact path={AdminRoutes.Blogs} element={<Blogs />} />
                <Route exact path={AdminRoutes.BlogsDetailsOne} element={<BlogsDetailsOne />} />
                <Route exact path={AdminRoutes.BlogsDetailsTwo} element={<BlogsDetailsTwo />} />
                <Route exact path={AdminRoutes.BlogsDetailsThree} element={<BlogsDetailsThree />} />
                <Route exact path={AdminRoutes.BlogsDetailsFour} element={<BlogsDetailsFour />} />
                <Route exact path={AdminRoutes.BlogsDetailsFive} element={<BlogsDetailsFive />} />
                <Route exact path={AdminRoutes.BlogsDetailsSix} element={<BlogsDetailsSix />} />
                <Route exact path={AdminRoutes.BlogsDetailsSeven} element={<BlogsDetailsSeven />} />

                {/*profile*/} 
                
                <Route exact path={AdminRoutes.PropertyOwnerProfile} element={<PropertyOwnerProfile />} />
                {/* <Route exact path={AdminRoutes.Profile} element={<Profile/>} />   */}
                <Route exact path={AdminRoutes.ChairmanProfile} element={<ChairmanProfile/>} /> 


                {/*Devloper*/}
                <Route exact path={AdminRoutes.DevloperDashboard} element={<DevloperDashboard />} />
                <Route exact path={AdminRoutes.DevloperRegisterPartner} element={<DevloperRegisterPartner />} />
                <Route exact path={AdminRoutes.DeveloperPayment} element={<DeveloperPayment />} />
                <Route exact path={AdminRoutes.DeveloperProfile} element={<DeveloperProfile />} />
                <Route exact path={AdminRoutes.DeveloperPortfolio} element={<DeveloperPortfolio />} />
                <Route exact path={AdminRoutes.DevloperVerification} element={<DevloperVerification />} />
                <Route exact path={AdminRoutes.DevloperProfileCompletion} element={<DevloperProfileCompletion />} />
                <Route exact path={AdminRoutes.DeveloperProfileDetails} element={<DeveloperProfileDetails />} />
                <Route exact path={AdminRoutes.DeveloperProfileEdit} element={<DeveloperProfileEdit />} />

                {/*otp verification*/}
                <Route exact path={AdminRoutes.OtpVerification} element={<OtpVerification />} />
                <Route exact path={AdminRoutes.OtpVerifictionOwner} element={<OtpVerifictionOwner />} />

                {/*PrivacyPolicy*/}
                <Route exact path={AdminRoutes.PrivacyPolicy} element={<PrivacyPolicy />} />

                {/*TermsAndCondistions*/}
                <Route exact path={AdminRoutes.TermsAndCondistions} element={<TermsAndCondistions />} />

                {/*Society*/}
                <Route exact path={AdminRoutes.SocietyConfigration} element={<SocietyConfigration />} />
                <Route exact path={AdminRoutes.SocietyDetails} element={<SocietyDetails />} />
                <Route exact path={AdminRoutes.SocietyPhotos} element={<SocietyPhotos />} />
                <Route exact path={AdminRoutes.SocietyBuildingDetails} element={<SocietyBuildingDetails />} />
                <Route exact path={AdminRoutes.WingsDetails} element={<WingsDetails />} />
                <Route exact path={AdminRoutes.FloorDetails} element={<FloorDetails />} />
                <Route exact path={AdminRoutes.UnitDetails} element={<UnitDetails />} />
                <Route exact path={AdminRoutes.SocietyOverview} element={<SocietyOverview />} />
                <Route exact path={AdminRoutes.SocietydashBoard} element={<SocietydashBoard />} />
                <Route exact path={AdminRoutes.SocietyProfile} element={<SocietyProfile/>} />

                

                {/*chairman*/}
                <Route exact path={AdminRoutes.ChairmanDashboard} element={<ChairmanDashboard />} />

                {/*Property Owner*/}
                <Route exact path={AdminRoutes.OwnerDashBoard} element={<OwnerDashBoard />} />

                 {/* {FlatOwnerProfile} */} 
                 
                 <Route exact path={AdminRoutes.FlatOwnerProfile} element={<FlatOwnerProfile/>} />


                {/*AboutUs*/}
                <Route exact path={AdminRoutes.AboutUs} element={<AboutUs />} />

                {/*Events*/}
              <Route exact path={AdminRoutes.EventsPage} element={<EventsPage />} />
               

              {/* SocietyFlatOwnerView */}
              <Route exact path={AdminRoutes.SocietyFlatOwnerView} element={<SocietyFlatOwnerView/>} />




            </Routes>
        </HashRouter>
    )
}

export default RouteIndex;