import React, { useEffect } from 'react';
import Layout from "../../Component/Layout/Layout";
import lakshminarayanan from "../../assets/images/lakshminarayanan.png";
import Pune_Federation_Logo from "../../assets/images/Pune-Federation-Logo.png"
import Global from "../../assets/images/global.png"

const AboutUs = () => {

    useEffect(() => {
        window.scrollTo(0, 0)
    }, [])

    return (
        <Layout>
        <div className="society-dashboards-cards-wrapper">
      <div className="society-dashboards-main-heading d-flex flex-column justify-content-center align-items-center">

        <h1 className="second-heading text-center">
          About Dreams Redeveloped</h1>
        <h1 className="first-heading text-center">
          Your one-stop Platform for all your Redevelopment Dream
        </h1>
      </div>
      </div>
            <div id="society-configuration-section" className="container-fluid form-section society-dashboard-with-banner-section">
                <div className="container-lg py-4 py-lg-5">
                    <div className="row">
                        <div className="col-12 col-sm-10 offset-sm-1 col-md-8 offset-md-2 px-0">
                            <div className="card custom-form-card p-4">
                                <h2 className="text-center text-purple m-0">About Us</h2>
                                <hr className="hr-custom-two mx-lg-auto mb-4"></hr>
                                <p className="mb-0 text-333333">Incorporated in the year 2020, Dreamsredeveloped is headquartered in Pune. We
                                    are the pioneer in providing a single platform for redevelopment ecosystem. Our aim at Dreamsredeveloped
                                    is to provide structured and simplified process of redevelopment, ensuring fast completion of
                                    documentation with 100% transparency. Along with all these features, the platform will cater to Senior
                                    Citizens in the most simplified way. We have successfully covered various locations in Pune including
                                    Kothrud, Sadashiv Peth, Patwardhan Baug and Prabhat Road.</p>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
            <section className="container-fluid bg-light py-5">
                <div className="container-lg bg-light">
                    <div className="row">
                        <div className="col-12 text-center mb-3">
                            <img src={Global} style={{ borderRadius: "50%" }} alt="" width="80px" height="auto" srcSet="" />
                        </div>

                        <h4 className="text-center text-purple mt-2">Our Vision</h4>
                        <p className="mb-0 text-center mb-5 text-333333">To touch a million Dreams across India through this Redevelopment
                            ecosystem</p>

                        <h4 className="text-center text-purple mt-2">Our Mission</h4>
                        <p className="mb-0 text-center text-333333">To build the most efficient Redevelopment ecosystem providing
                            Structure, Simplicity and Transparency</p>

                    </div>
                </div>
            </section>

            <section className="container-fluid bg-white py-5">
                <div className="container-lg bg-white">
                    <h4 className="text-center text-purple mt-2 mb-3 fs-4">Our Founder</h4>
                    <div className="row">
                        <div className="col-12 text-center mb-3">
                            <img src={lakshminarayanan} className="about-us-founder-image img-fluid" alt="" srcSet="" />
                            <p className="fs-1">CA S Lakshminarayanan</p>
                        </div>
                        <p className="mb-3 text-333333">An alumnus of Indian School of Business, CA (First Attempt) in the year 2004 and a
                            seasoned finance professional with over 18 years of diversified experience in setting up start-ups and
                            working with established organizations across Financial Services like Stock & Power Exchanges, NBFC as well
                            as Tech services. His forte lies in Negotiations, seeking new opportunities, strategizing, and building high
                            impact teams that ultimately lead to the creation and addition of high value intangibles.</p>
                        <p className="mb-3 text-333333">As a person who went through the redevelopment process personally, he understood
                            the information asymmetry that exists in this space across the process. Having understood the nuances, he
                            has taken this stride to create an ecosystem to help Societies and Developers in this end-to-end
                            Redevelopment process. The aim is to facilitate a smooth, transparent, and fast redevelopment process by
                            guiding Societies to get 100% ready for Redevelopment and Developers with discovery and bidding process.</p>
                        <p className="mb-3 text-333333">Apart from being an avid reader, his other passions include teaching, mentoring,
                            and reading.</p>
                    </div>
                    <div className="col-12 d-flex flex-row justify-content-center pb-4">
                        <a href="https://www.linkedin.com/in/lakshminarayananselvaraj/" target="_blank" className="text-decoration-none">
                            <i className="fa fa-3x fa-linkedin about-us-linkedin-icon" aria-hidden="true"></i>
                        </a>
                    </div>
                </div>
            </section>
            <section className="container-fluid bg-light py-5">
                <div className="container-lg py-4">

                    <div className="row">
                        <div className="col-12 col-md-4 text-center">
                            <img src={Pune_Federation_Logo} className="mb-3 mb-md-0" alt="" width="180px" height="auto"
                                srcSet="" />
                        </div>
                        <div className="col-12 col-md-8">
                            <p className="mb-3 fw-bold">Official Knowledge Partner with "Pune District Co Op Housing and Apartments
                                Federation Ltd." Chairman Mr. Suhas Patwardhan</p>
                            <p className="mb-3 text-333333">Dreams Redeveloped is glad to announce this major partnership with Pune’s
                                leading federation for housing societies. With this association, we are now equipped to serve Societies
                                for their redevelopment needs as well as their other requirements.</p>

                            <div className="d-flex flex-row justify-content-center justify-content-md-start">
                                <a href="http://www.punefed.com/" target="_blank">
                                    <button type="button" className="btn btn-purple-custom px-5 mx-auto">Visit Site  </button>
                                </a>
                            </div>

                        </div>
                    </div>


                </div>
            </section>
        </Layout>
    )
}

export default AboutUs