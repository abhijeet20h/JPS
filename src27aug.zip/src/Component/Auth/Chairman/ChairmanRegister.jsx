import React, { useState, useEffect } from 'react';
import Layout from '../../Layout/Layout';
import { useNavigate } from "react-router-dom";
import AdminRoutes from '../../../App/Route/RouteDetails';
import { toast } from 'react-toastify';
import baseApi from "../../../environment/Config";
import axios from 'axios';


const ChairmanRegister = () => {
    const navigate = useNavigate();
    const initialDevStep1Values = { SocietyName: "", FullName: "", MobileNo: "", EmailId: "" };
    const [RegisterData, setRegisterData] = useState(initialDevStep1Values);
    const [formErrors, setFormErrors] = useState({});
    const [isSubmit, setisSubmit] = useState(false);
    const [LatterOfAppointment, setLatterOfAppointment] = useState("")
    const [latterImage, setLatterImage] = useState("")
    const [spinner, setSpinner] = useState(false);

    useEffect(() => {
        window.scrollTo(0, 0)
    }, [])

    const handleChange = (e) => {
        const { name, value } = e.target;
        setRegisterData({ ...RegisterData, [name]: value });
    };

    const validateDevStep1 = (values) => {
        const errors = {};
        const regex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i;
        const regfornum = /^[0-9]*$/;
        const deigicheck = /^(\+\d{1,3}[- ]?)?\d{10}$/

        if (!values?.EmailId) {
            errors.EmailId = "Email is required!";
        } else if (!regex.test(values?.EmailId)) {
            errors.EmailId = "This is not a valid email format!";
        }

        if (!values?.MobileNo) {
            errors.MobileNo = "Mobile Numberis required!";
        } else if (!regfornum.test(values?.MobileNo)) {
            errors.MobileNo = "Enter Numbers Only!";
        } else if (!values?.MobileNo.match(deigicheck)) {
            errors.MobileNo = "Enter Valid Mobile Number!";
        }

        return errors;
    };

    // api calling
    useEffect(() => {
        submitApi()
    }, [formErrors])

    const submitApi = async () => {
        if (Object.keys(formErrors).length === 0 && isSubmit) {
            console.log("api calling")
            // navigate(AdminRoutes.OtpVerification)

            var data = JSON.stringify({
                "society_name": RegisterData.SocietyName,
                "name": RegisterData.FullName, // full name   
                "appointment_letter": LatterOfAppointment === 'Get flat owners to verify' ? "Get flat owners to verify" : latterImage?.file_path,
                "choose_property": "",
                "property_type": "",
                "gross_plot_area": 0,
                "society_photos": [],
                "no_of_buildings": 0,
                "no_of_floors": 0,
                "no_of_flats": 0,
                "garage": 0,
                "outhouse": 0,
                "shopes": 0,
                "offices": 0,
                "building_info": {},
                "email": RegisterData.EmailId,
                "mobile": parseInt(RegisterData.MobileNo), //number
                "company_name": "",
                "entity_name": "",
                "Website": "",
                "service_year": 0,
                "redevelopment_year": 0,
                "expertise": "",
                "company_logo": "",
                "Payment_Link_Id": "",
                "balance_sheet": "",
                "income_tax_return": "",
                "cibil_score": "",
                "partners_info": [],
                "roles": 1
            });

            var config = {
                method: 'post',
                url: `${baseApi.baseUrl}user/usercreate`,
                headers: {
                    'Content-Type': 'application/json'
                },
                data: data
            };

            await axios(config)
                .then(function (response) {
                    if (response.data.status === 1) {
                        toast(response.data.message);
                        navigate('/otp_verification/' + RegisterData.MobileNo + '/' + 1 + '/registr')
                    } else {
                        toast(response.data.message);
                    }
                })
                .catch(function (error) {
                    console.log(error);
                });

        }
    }

    //subitbtn handle btn handle
    const handleSubmit = (e) => {
        e.preventDefault();
        setFormErrors(validateDevStep1(RegisterData));
        setisSubmit(true);
    }


    //handle upload file for latter of appointment
    const handleCompanyLogoFile = (e) => {
        setSpinner(true)
        try {
            var formdata = new FormData();
            formdata.append("file", e.target.files[0], e.target.files[0]?.name);

            var requestOptions = {
                method: 'POST',
                body: formdata,
                redirect: 'follow'
            };

            fetch(`${baseApi.baseUrl}fileupload`, requestOptions)
                .then(response => response.text())
                .then(result => handleompanyLogo(result))
        } catch (err) {
            console.log(err.res)
            setSpinner(false)
        }
    }

    //setlatter of appointment
    const handleompanyLogo = (result) => {
        setLatterImage(JSON.parse(result))
        setSpinner(false)
    }


    return (
        <Layout>
            <div id="chairman-reg-section" className="container-fluid margin-top-first-container-small form-section">
                <div className="container-lg py-4 py-lg-5">

                    <h2 className="text-start text-lg-center text-purple">Chairman Registration</h2>
                    <hr className="hr-custom-two mx-lg-auto mb-4 mb-lg-5"></hr>

                    <div className="row g-3 g-lg-5">
                        <div className="col-12 col-sm-6 col-md-4">
                            <div className="card custom-form-card p-3">
                                <label htmlFor="exampleFormControlInput1" className="form-label mb-2">Society Name</label>
                                <input type="text" name='SocietyName' className="form-control" id="exampleFormControlInput1" placeholder="Enter Society Name" onChange={(e) => handleChange(e)} />
                            </div>
                        </div>

                        <div className="col-12 col-sm-6 col-md-4">
                            <div className="card custom-form-card p-3">
                                <label htmlFor="exampleFormControlInput1" className="form-label mb-2">Chairman's Full Name</label>
                                <input type="text" name='FullName' className="form-control" id="exampleFormControlInput1" placeholder="Enter Chairman's Full Name" onChange={(e) => handleChange(e)} />
                            </div>
                        </div>

                        <div className="col-12 col-sm-6 col-md-4">
                            <div className="card custom-form-card p-3">
                                <label htmlFor="exampleFormControlInput1" className="form-label mb-2"><span className="text-danger">*</span> Mobile No.</label>
                                <input type="text" name='MobileNo' className="form-control" id="exampleFormControlInput1" placeholder="Enter digits" onChange={(e) => handleChange(e)} />
                                <p className='text-danger mb-0'>{formErrors?.MobileNo}</p>
                            </div>
                        </div>

                        <div className="col-12 col-sm-6 col-md-4">
                            <div className="card custom-form-card p-3">
                                <label htmlFor="exampleFormControlInput1" className="form-label mb-2"><span className="text-danger">*</span> Email ID</label>
                                <input type="text" name='EmailId' className="form-control" id="exampleFormControlInput1" placeholder="Enter Email id" onChange={(e) => handleChange(e)} />
                                <p className='text-danger mb-0'>{formErrors?.EmailId}</p>
                            </div>
                        </div>

                        <div className="col-12 col-sm-6 col-md-4">
                            <div className="card custom-form-card p-3">
                                <label htmlFor="exampleFormControlInput1" className="form-label mb-2">Letter of appointment</label>
                                <div className="form-check custom-form-check">
                                    <input className="form-check-input" value="Upload document" type="radio" name="exampleRadios" id="exampleRadios1" onChange={(e) => setLatterOfAppointment(e.target.value)} />
                                    <label className="form-check-label fw-500" htmlFor="exampleRadios1">
                                        Upload document
                                    </label>
                                </div>
                                <div className="form-check custom-form-check">
                                    <input className="form-check-input" value="Get flat owners to verify" type="radio" name="exampleRadios" id="exampleRadios2" onChange={(e) => setLatterOfAppointment(e.target.value)} />
                                    <label className="form-check-label fw-500" htmlFor="exampleRadios2">
                                        Get flat owners to verify
                                    </label>
                                </div>
                            </div>
                        </div>

                        {LatterOfAppointment === 'Upload document' ?
                            <div className="col-12 col-sm-6 col-md-4">
                                <div className="card custom-form-card p-3 flex-column align-items-center">
                                    <label htmlFor="exampleFormControlInput1" className="form-label mb-2 text-start align-self-start">Upload Letter of appointment</label>
                                    {spinner ?
                                        <>
                                            <span className="custom-drag-box" >
                                                <div className="spinner-grow text-warning" role="status">
                                                    <span className="sr-only">Loading...</span>
                                                </div>
                                                <input type="file" id="uploadFile" accept="image/png, image/gif, image/jpeg" onChange={(e) => handleCompanyLogoFile(e)} />
                                            </span>
                                        </>

                                        :
                                        latterImage ?
                                            <>
                                                <br></br>
                                                <span className="custom-drag-box" >
                                                    <div className='d-flex flex-columns align-items-center'>
                                                        <i className="fa fa-2x fa-check-circle me-2 text-orange text-20px" aria-hidden="true"></i>
                                                        <span className="custom-drag-box-text">document Uploaded</span>
                                                        <input type="file" id="uploadFile" accept="image/png, image/gif, image/jpeg" onChange={(e) => handleCompanyLogoFile(e)} />
                                                    </div>
                                                </span>
                                                <br></br>
                                            </>
                                            :
                                            <>
                                                <br></br>
                                                <span className="custom-drag-box" >
                                                    <i className="fa fa-file-image-o d-block custom-drag-box-icon" aria-hidden="true"></i>
                                                    <span className="custom-drag-box-text">Upload your document</span>
                                                    <input type="file" id="uploadFile" accept="image/png, image/gif, image/jpeg" onChange={(e) => handleCompanyLogoFile(e)} />
                                                </span>
                                                <br></br>
                                            </>
                                    }
                                </div>
                            </div>
                            : null}

                        <div className="col-12 mt-5 mt-lg-5 mb-4 mb-lg-0">
                            <div className="d-flex flex-column justify-content-center align-items-center">
                                <button type="button" className="btn btn-purple-custom px-5 text-white" onClick={(e) => handleSubmit(e)}>Verify via Mobile OTP</button>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </Layout>
    )
}

export default ChairmanRegister