import React, { useState, useEffect } from 'react';
import Layout from '../../Layout/Layout';
import AdminRoutes from '../../../App/Route/RouteDetails';
import { useNavigate } from "react-router-dom";


const CommunityRegister = () => {
    const navigate = useNavigate();
    const [selectRole, setSelectRole] = useState(false);

    useEffect(() => {
        window.scrollTo(0, 0)
    }, [])

    //handle role which select
    const RoleHandle = (role) => {
        setSelectRole(role)
    }

    //for redirect page
    const handleReDirect = () => {
        navigate(selectRole)
        if (selectRole === '/register_society/:selectauth') {
            console.log("selected", selectRole)
            navigate('/register_society/' + "login") 
        }
    }

    // handle register 
    const handleReDirectRegister = () => {
        if (selectRole === '/devloper_login') {
            navigate('/devloper_register')
        }

        if (selectRole === '/register_society/:selectauth') {
            navigate('/register_society/' + "register")
        }
    }

    return (
        <Layout>
            <div id="login-section" className="container-fluid margin-top-first-container-large">
                <div className="container-lg py-4 py-lg-5">
                    <h2 className="text-center text-lg-start mb-4 text-purple">Welcome to <br className="d-block d-lg-none"></br> <strong>Dreams Redeveloped</strong> <br className="d-block d-lg-none"></br> Community
                    </h2>
                    <hr className="hr-custom-one mx-auto ms-lg-0 mb-4 mb-lg-5 text-start text-lg-start"></hr>
                    <p className="fst-italic fw-normal text-16 text-purple text-center text-lg-start mb-5">You are registering for the community as…</p>

                    <div className="row g-3 g-lg-5">
                        <div className="col-6 col-sm-6 col-md-3">
                            <div className="d-flex flex-column align-items-center item-className-custom" onClick={() => RoleHandle(AdminRoutes.SocietyRegister)}>
                                <div className={selectRole === AdminRoutes.SocietyRegister ? "login-role-image-placeholder mb-4 d-flex align-items-center justify-content-center role-icon-active selectedIcon cursor-pointer" : "login-role-image-placeholder mb-4 d-flex align-items-center justify-content-center cursor-pointer"}>
                                    <svg xmlns="http://www.w3.org/2000/svg" width="40.502" height="40.5" viewBox="0 0 40.502 40.5">
                                        <g id="Group_8559" data-name="Group 8559" transform="translate(15159 -4531)" opacity="0.7">
                                            <path id="Icon_awesome-hand-holding" data-name="Icon awesome-hand-holding" d="M39.748,23.07a2.327,2.327,0,0,0-3,0l-6.5,5.2a4.476,4.476,0,0,1-2.812.984H19.125a1.125,1.125,0,0,1,0-2.25H24.63a2.341,2.341,0,0,0,2.341-1.87A2.253,2.253,0,0,0,24.75,22.5H13.5a8.275,8.275,0,0,0-5.21,1.849L5.02,27h-3.9A1.128,1.128,0,0,0,0,28.125v6.75A1.128,1.128,0,0,0,1.125,36H26.212a4.505,4.505,0,0,0,2.813-.984l10.631-8.508A2.249,2.249,0,0,0,39.748,23.07Z" transform="translate(-15159 4535.5)" />
                                            <path id="Path_5881" data-name="Path 5881" d="M24.951,23.13H9.434a1.108,1.108,0,0,1-1.108-1.108V12.046H5L16.447,1.64a1.108,1.108,0,0,1,1.492,0L29.385,12.046H26.06v9.976a1.108,1.108,0,0,1-1.108,1.108ZM10.542,20.913h13.3V10l-6.65-6.045L10.542,10Z" transform="translate(-15158.062 4529.648)" />
                                        </g>
                                    </svg>

                                </div>
                                <p className="text-purple fw-500">Property Owner</p>
                            </div>
                        </div>

                        <div className="col-6 col-sm-6 col-md-3">
                            <div className="d-flex flex-column align-items-center item-className-custom" onClick={() => RoleHandle(AdminRoutes.DevloperLogin)}>
                                <div className={selectRole === AdminRoutes.DevloperLogin ? "login-role-image-placeholder mb-4 d-flex align-items-center justify-content-center role-icon-active selectedIcon cursor-pointer" : "login-role-image-placeholder mb-4 d-flex align-items-center justify-content-center cursor-pointer"}>
                                    <svg xmlns="http://www.w3.org/2000/svg" width="40.502" height="40.5" viewBox="0 0 40.502 40.5">
                                        <g id="Group_8560" data-name="Group 8560" transform="translate(15102 -4531)" opacity="0.7">
                                            <path id="Icon_awesome-hand-holding" data-name="Icon awesome-hand-holding" d="M39.748,23.07a2.327,2.327,0,0,0-3,0l-6.5,5.2a4.476,4.476,0,0,1-2.812.984H19.125a1.125,1.125,0,0,1,0-2.25H24.63a2.341,2.341,0,0,0,2.341-1.87A2.253,2.253,0,0,0,24.75,22.5H13.5a8.275,8.275,0,0,0-5.21,1.849L5.02,27h-3.9A1.128,1.128,0,0,0,0,28.125v6.75A1.128,1.128,0,0,0,1.125,36H26.212a4.505,4.505,0,0,0,2.813-.984l10.631-8.508A2.249,2.249,0,0,0,39.748,23.07Z" transform="translate(-15102 4535.5)" />
                                            <path id="Path_5874" data-name="Path 5874" d="M7.2,20.791V6.152a1.1,1.1,0,0,1,.724-1.035L18.57,1.247a.55.55,0,0,1,.739.517V7.216l6.952,2.317a1.1,1.1,0,0,1,.753,1.045V20.791h2.2v2.2H5v-2.2Zm2.2,0h7.7V4.121l-7.7,2.8Zm15.41,0v-9.42l-5.5-1.835V20.791Z" transform="translate(-15099.01 4529.786)" />
                                        </g>
                                    </svg>

                                </div>
                                <p className="text-purple fw-500">Developer</p>
                            </div>
                        </div>

                        <div className="col-6 col-sm-6 col-md-3">
                            <div className="d-flex flex-column align-items-center item-className-custom" onClick={() => RoleHandle(0)}>
                                <div className="login-role-image-placeholder-deactivated mb-4 d-flex align-items-center justify-content-center">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="41.445" height="42.569" viewBox="0 0 41.445 42.569">
                                        <g id="settings" transform="translate(-2.715 -2.295)" opacity="0.2">
                                            <path id="Path_5894" data-name="Path 5894" d="M40.2,24.738V22.405l2.927-2.561a3.049,3.049,0,0,0,.579-3.888l-3.6-6.1A3.074,3.074,0,0,0,36.5,8.486L32.79,9.735a17.3,17.3,0,0,0-2-1.144l-.778-3.842A3.049,3.049,0,0,0,26.965,2.3H19.83a3.049,3.049,0,0,0-3.049,2.454L16,8.592a17.5,17.5,0,0,0-2.013,1.144L10.363,8.423a3.049,3.049,0,0,0-.974-.091A3.049,3.049,0,0,0,6.751,9.857l-3.6,6.1a3.049,3.049,0,0,0,.625,3.827L6.659,22.42v2.332L3.778,27.314A3.049,3.049,0,0,0,3.153,31.2l3.6,6.1a3.074,3.074,0,0,0,3.613,1.371l3.705-1.25a17.3,17.3,0,0,0,2,1.144l.778,3.842a3.049,3.049,0,0,0,3.049,2.454h7.2a3.049,3.049,0,0,0,3.049-2.454l.778-3.842a17.5,17.5,0,0,0,2.013-1.144l3.69,1.25A3.074,3.074,0,0,0,40.233,37.3l3.476-6.1a3.049,3.049,0,0,0-.625-3.827ZM37.471,35.776l-5.23-1.769A13.508,13.508,0,0,1,28.109,36.4l-1.081,5.474h-7.2l-1.083-5.413a14.27,14.27,0,0,1-4.117-2.393L9.388,35.776l-3.6-6.1,4.147-3.659a13.57,13.57,0,0,1,0-4.772L5.79,17.48l3.6-6.1,5.23,1.769a13.508,13.508,0,0,1,4.132-2.393l1.081-5.474h7.2L28.111,10.7a14.271,14.271,0,0,1,4.117,2.393l5.243-1.708,3.6,6.1L36.922,21.14a13.57,13.57,0,0,1,0,4.772l4.147,3.766Z" transform="translate(0)" />
                                            <path id="Path_5895" data-name="Path 5895" d="M20.4,29.546a9.057,9.057,0,1,1,6.5-2.652A9.148,9.148,0,0,1,20.4,29.546Zm0-15.246a5.962,5.962,0,0,0-6.1,6.1,5.962,5.962,0,0,0,6.1,6.1,5.962,5.962,0,0,0,6.1-6.1,5.962,5.962,0,0,0-6.1-6.1Z" transform="translate(3.032 3.181)" />
                                        </g>
                                    </svg>
                                </div>
                                <p className="text-purple fw-500" style={{opacity:"0.5"}}>Service Provider</p>
                            </div>
                        </div>

                        <div className="col-6 col-sm-6 col-md-3">
                            <div className="d-flex flex-column align-items-center item-className-custom" onClick={() => RoleHandle(0)}>
                                <div className="login-role-image-placeholder-deactivated mb-4 d-flex align-items-center justify-content-center">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="44.348" height="42.5" viewBox="0 0 434.348 332.5">
                                        <g id="noun-raw-material-4416381" transform="translate(-132.647 -113.755)" opacity="0.2">
                                            <path id="Path_5974" data-name="Path 5974" d="M548.62,378.88c23.625-72.625,23.625-147.88,0-220.5,10.5-1.75,18.375-11.375,18.375-22.75a21.663,21.663,0,0,0-21.875-21.875H350.87c-12.25,0-21.875,9.625-21.875,22.75A22.467,22.467,0,0,0,347.37,158.38c-5.25,15.75-9.625,31.5-12.25,48.125a66.561,66.561,0,0,0-16.625,10.5l-3.5,2.625-1.75-1.75c-28-29.75-76.125-30.625-105.88-2.625l-39.375,36.75H141.74a7.958,7.958,0,0,0-7,3.5,8.393,8.393,0,0,0-1.75,7.875l26.25,93.625a54.738,54.738,0,0,0,42,89.25c27.125,0,49.875-20.125,53.375-45.5h78.75c4.375,26.25,26.25,45.5,53.375,45.5a53.846,53.846,0,0,0,43.75-21.875H544.24c12.25,0,21.875-9.625,21.875-22.75a21.235,21.235,0,0,0-17.5-22.75ZM350.87,132.13H545.12c2.625,0,4.375,1.75,4.375,5.25a4.133,4.133,0,0,1-4.375,4.375H350.87c-2.625,0-4.375-1.75-4.375-5.25A4.133,4.133,0,0,1,350.87,132.13Zm14,27.125H530.25c25.375,71.75,25.375,147,0,219.62H440.125a47.691,47.691,0,0,0-10.5-21L437.5,329a35.892,35.892,0,0,0,9.625.875,60.375,60.375,0,0,0,0-120.75,59.756,59.756,0,0,0-35,11.375C400.75,210,386.75,203,371,201.25a64.641,64.641,0,0,0-18.375,0c3.5-14,7.875-28,12.25-42Zm90.125,96.25c-1.75-1.75-4.375-3.5-7-3.5h-10.5l-13.125-17.5a38.392,38.392,0,0,1,23.625-7.875,42.875,42.875,0,0,1,0,85.75h-5.25l13.125-48.125C456.745,259.88,456.745,257.255,454.995,255.505Zm-84.875-36.75c14.875,1.75,28,8.75,36.75,21l9.625,12.25H302.745l26.25-21.875C340.37,220.505,355.245,217.005,370.12,218.755Zm-151.38,8.75c22.75-21.875,59.5-20.125,81.375,2.625l.875.875-25.375,21H192.49Zm217.88,42-21,75.25c-7.875-5.25-17.5-7.875-28-7.875a52.706,52.706,0,0,0-42,20.125.857.857,0,0,1-.875.875c-5.25,7-9.625,15.75-10.5,24.5h-78.75c-4.375-26.25-26.25-45.5-53.375-45.5a56.835,56.835,0,0,0-27.125,7l-21-75.25h282.62ZM201.24,427.885a36.75,36.75,0,1,1,36.75-36.75C238.865,411.26,222.24,427.885,201.24,427.885Zm186.38,0a36.75,36.75,0,1,1,36.75-36.75A36.972,36.972,0,0,1,387.62,427.885Zm157.5-21.875h-105c.875-3.5,1.75-6.125,1.75-9.625H545.12c2.625,0,4.375,1.75,4.375,5.25A4.133,4.133,0,0,1,545.12,406.01Z" />
                                        </g>
                                    </svg>
                                </div>
                                <p className="text-purple fw-500" style={{opacity:"0.5"}}>Raw material provider</p>
                            </div>
                        </div>

                        <div className="col-12 mt-5 mt-lg-5 mb-4 mb-lg-0">
                            <div className="d-flex flex-column justify-content-center align-items-center">
                                <button type="button" className={selectRole ? "btn btn-purple-custom px-5 text-white" : "btn btn-gray-custom px-5"} onClick={() => handleReDirect()}>Login</button>
                                <p className="mt-3"><span className="text-center text-purple hover-purple fw-bold cursor-pointer text-decoration-underline" onClick={() => handleReDirectRegister()}>Register Now</span></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </Layout>
    )
}

export default CommunityRegister