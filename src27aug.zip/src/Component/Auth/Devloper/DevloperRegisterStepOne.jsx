import React, { useState, useEffect } from 'react'
import { useNavigate, useParams } from "react-router-dom";
import Layout from '../../Layout/Layout'
import AdminRoutes from '../../../App/Route/RouteDetails';
import { toast } from 'react-toastify';
import axios from 'axios'
import baseApi from "../../../environment/Config"
import FlieuploadModal from '../../Shared/Modal/FlieuploadModal';
import DRlogo from '../../../assets/images/global.png'

const DevloperRegisterStepOne = () => {
    const navigate = useNavigate();
    const { cemail } = useParams();
    const { ename } = useParams();
    const { mobileno } = useParams();

    const initialDevStep1Values = { EName: "", website: "", address: "", yearinservice: "", Yearindev: "", expertise: "", CmpLogo: "" };
    const [formValuesDevStep1, setFormValuesDevStep1] = useState(initialDevStep1Values);
    const [formDevStep1Errors, setFormDevStep1Errors] = useState({});
    const [isSubmitDevStep1, setisSubmitDevStep1] = useState(false);
    const [compnayLogo, setCompanyLogo] = useState(null);
    const [verifyDevloper, setVerifyDevloper] = useState(null)
    const [spinner, setSpinner] = useState(false);

    useEffect(() => {
        window.scrollTo(0, 0)
    }, [])

    // for the set data
    const handleChangeDevStep1 = (e) => {
        const { name, value } = e.target;
        setFormValuesDevStep1({ ...formValuesDevStep1, [name]: value });
    };

    const validateDevStep1 = (values, compnayLogo) => {
        const errors = {};
        const regfornum = /^[0-9]*$/;

        if (!values?.EName) {
            errors.EName = "Entity Name is required!";
        }
        if (!values?.address) {
            errors.address = "Address is required!";
        }
        if (!values?.yearinservice) {
            errors.yearinservice = "Years in services is required!";
        } else if (!regfornum.test(values?.yearinservice)) {
            errors.yearinservice = "Enter year!";
        }
        if (!values?.Yearindev) {
            errors.Yearindev = "Years in redevelopment is required!";
        } else if (!regfornum.test(values?.Yearindev)) {
            errors.Yearindev = "Enter year!";
        }

        if (!compnayLogo) {
            errors.compnayLogo = "please Select Logo!";
        }




        return errors;
    };

    //subitbtn handle btn handle
    const handleSubmitDevStep1 = (e) => {
        e.preventDefault();
        setFormDevStep1Errors(validateDevStep1(formValuesDevStep1, compnayLogo));
        setisSubmitDevStep1(true);
    }

    useEffect(() => {
        if (Object.keys(formDevStep1Errors).length === 0 && isSubmitDevStep1 && compnayLogo?.file_path.length) {
            handleApi()
        }
    }, [formDevStep1Errors])

    const handleApi = async () => {
        var data = JSON.stringify({
            "email": cemail,
            "mobile": parseInt(mobileno),
            "company_name": ename,
            "entity_name": formValuesDevStep1.EName,
            "Website": formValuesDevStep1.website,
            "address": formValuesDevStep1.address,
            "service_year": parseInt(formValuesDevStep1.yearinservice), //number
            "redevelopment_year": parseInt(formValuesDevStep1.Yearindev), //number
            "expertise": formValuesDevStep1.expertise,
            "company_logo": compnayLogo?.file_path,
            "Payment_Link_Id": '',
            "paid_ammount": 0,
            "varified_developer": parseInt(verifyDevloper),
            // "order_id": "waesrdfghjh",
            // "payment_id": "aesrdfh",
            // "signature": "erjrtytrtertyuytr",
            "partners_info": [],
            "roles": 3
        });

        var config = {
            method: 'post',
            url: `${baseApi.baseUrl}user/usercreate`,
            headers: {
                'Content-Type': 'application/json'
            },
            data: data
        };

        await axios(config)
            .then(function (response) {
                console.log(response.data);
                if (response.data.status === 1) {
                    toast(response.data.message);
                    navigate('/otp_verification/' + cemail + '/' + 3 + '/registr')
                } else {
                    toast(response.data.message);
                }
            })
            .catch(function (error) {
                if (error?.response.data?.message) {
                    toast(error?.response.data?.message);
                }
            });
    }


    //handle developer verified 
    const handleDeveloper = (value) => {
        setVerifyDevloper(value)
        var data = JSON.stringify({
            "varified": value
        });

        var config = {
            method: 'post',
            url: `${baseApi.baseUrl}useramount/getamount`,
            headers: {
                'Content-Type': 'application/json'
            },
            data: data
        };

        axios(config)
            .then(function (response) {
                localStorage.setItem("drDevloperAmount", JSON.stringify(response.data))
            })
            .catch(function (error) {
                console.log(error);
            });
    }


    // save form
    const handleRegisterOne = () => {
        toast('🦄 Wow so easy!');
        navigate(AdminRoutes.DevloperRegisterStepTwo)
    }


    //handle upload file for logo
    const handleCompanyLogoFile = (e) => {
        setSpinner(true)
        try {
            var formdata = new FormData();
            formdata.append("file", e.target.files[0], e.target.files[0]?.name);

            var requestOptions = {
                method: 'POST',
                body: formdata,
                redirect: 'follow'
            };

            fetch(`${baseApi.baseUrl}fileupload`, requestOptions)
                .then(response => response.text())
                .then(result => handleompanyLogo(result))
        } catch (err) {
            console.log(err.res)
            setSpinner(false)
        }
    }

    //set logo link
    const handleompanyLogo = (result) => {
        setCompanyLogo(JSON.parse(result))
        setSpinner(false)
    }

    return (
        <Layout>
            <div className="modal fade" id="popup-select-upload-method" tabIndex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <FlieuploadModal />
            </div>
            <div id="chairman-reg-section" className="container-fluid margin-top-first-container-small form-section">
                <div className="container-lg py-4 py-lg-5">

                    <h2 className="text-start text-lg-center text-purple">Developer Registration</h2>
                    <hr className="hr-custom-two mx-lg-auto mb-4 mb-lg-5"></hr>


                    <div className="row g-3 g-lg-5">
                        <div className="col-12 col-sm-6 col-md-4">
                            <div className="card custom-form-card p-3">
                                <label htmlFor="exampleFormControlInput1" className="form-label mb-2"><span className="text-danger">* </span>Entity Name</label>
                                <input type="text" className="form-control" id="exampleFormControlInput1" placeholder="Enter Full Name" maxLength="35" name='EName' onChange={(e) => handleChangeDevStep1(e)} />
                                <p className='text-danger mb-0'>{formDevStep1Errors?.EName}</p>
                            </div>
                        </div>

                        <div className="col-12 col-sm-6 col-md-4">
                            <div className="card custom-form-card p-3">
                                <label htmlFor="exampleFormControlInput1" className="form-label mb-2">Website</label>
                                <input type="text" className="form-control" id="exampleFormControlInput1" placeholder="Enter website URL" name='website' onChange={(e) => handleChangeDevStep1(e)} />
                            </div>
                        </div>

                        <div className="col-12 col-sm-6 col-md-4">
                            <div className="card custom-form-card p-3">
                                <label htmlFor="exampleFormControlInput1" className="form-label mb-2"><span className="text-danger">* </span>Address</label>
                                <input type="text" className="form-control" id="exampleFormControlInput1" placeholder="Enter address" maxLength="35" name='address' onChange={(e) => handleChangeDevStep1(e)} />
                                <p className='text-danger mb-0'>{formDevStep1Errors?.address}</p>
                            </div>
                        </div>

                        <div className="col-12 col-sm-6 col-md-4">
                            <div className="card custom-form-card p-3">
                                <label htmlFor="exampleFormControlInput1" className="form-label mb-2"><span className="text-danger">* </span>Years in services</label>
                                <div className="input-group mb-3">
                                    <input type="text" className="form-control input-group-first-input"
                                        placeholder="00" aria-label="Text input with dropdown button" name='yearinservice' onChange={(e) => handleChangeDevStep1(e)} />
                                    <span className="input-group-text" id="basic-addon2">Years</span>
                                </div>
                                <p className='text-danger mb-0'>{formDevStep1Errors?.yearinservice}</p>
                            </div>
                        </div>

                        <div className="col-12 col-sm-6 col-md-4">
                            <div className="card custom-form-card p-3">
                                <label htmlFor="exampleFormControlInput1" className="form-label mb-2"><span className="text-danger">* </span>Years in redevelopment</label>
                                <div className="input-group mb-3">
                                    <input type="text" className="form-control input-group-first-input"
                                        placeholder="00" aria-label="Text input with dropdown button" name='Yearindev' onChange={(e) => handleChangeDevStep1(e)} />
                                    <span className="input-group-text" id="basic-addon2">Years</span>
                                </div>
                                <p className='text-danger mb-0'>{formDevStep1Errors?.Yearindev}</p>
                            </div>
                        </div>

                        <div className="col-12 col-sm-6 col-md-4">
                            <div className="card custom-form-card p-3">
                                <label htmlFor="exampleFormControlInput1" className="form-label mb-2">Your expertise</label>
                                <textarea className="form-control" id="exampleFormControlTextarea1" rows="3" placeholder="Enter your vision & ambition here" name='expertise' onChange={(e) => handleChangeDevStep1(e)}></textarea>
                            </div>
                        </div>



                        <div className="col-12 col-sm-6 col-md-4">
                            <div className="card custom-form-card p-3 flex-column align-items-center">
                                <label htmlFor="exampleFormControlInput1" className="form-label mb-2 text-start align-self-start"><span className="text-danger">* </span>Company logo</label>
                                {spinner ?
                                    <>
                                        <span className="custom-drag-box cursor-pointer" >
                                            <div className="spinner-grow text-warning" role="status">
                                                <span className="sr-only">Loading...</span>
                                            </div>
                                            <input type="file" id="uploadFile" accept="image/png, image/gif, image/jpeg" onChange={(e) => handleCompanyLogoFile(e)} />
                                        </span>
                                    </>

                                    :
                                    compnayLogo ?
                                        <>
                                            <br></br>
                                            <span className="custom-drag-box cursor-pointer" >
                                                <div className='d-flex flex-columns align-items-center'>
                                                    <i className="fa fa-2x fa-check-circle me-2 text-orange text-20px" aria-hidden="true"></i>
                                                    {/* <div className="form-upload-photo-preview mt-3" style={{ backgroundImage: `url(${compnayLogo})` }} ></div> */}
                                                    <span className="custom-drag-box-text ">logo Uploaded</span>
                                                    <input type="file" id="uploadFile" accept="image/png, image/gif, image/jpeg" onChange={(e) => handleCompanyLogoFile(e)} />
                                                </div>
                                            </span>
                                            <br></br>
                                        </>
                                        :
                                        <>
                                            <br></br>
                                            <span className="custom-drag-box cursor-pointer" >
                                                <i className="fa fa-file-image-o d-block custom-drag-box-icon" aria-hidden="true"></i>
                                                <span className="custom-drag-box-text">Upload your logo</span>
                                                <input type="file" id="uploadFile" accept="image/png, image/gif, image/jpeg" onChange={(e) => handleCompanyLogoFile(e)} />
                                            </span>
                                            <br></br>
                                        </>
                                }
                            </div>
                            <p className='text-danger mb-0'>{formDevStep1Errors?.compnayLogo}</p>
                        </div>

                        <div className="col-12 col-sm-6 col-md-4">
                            <div className="card custom-form-card p-3">
                                <label htmlFor="exampleFormControlInput1" className="form-label mb-2"><span className="text-danger">* </span>Are you a verified developer?</label>
                                <div className="form-check custom-form-check">
                                    <input className="form-check-input" value="1" type="radio" name="exampleRadios" id="exampleRadios1" onChange={() => handleDeveloper(1)} />
                                    <label className="form-check-label fw-500" htmlFor="exampleRadios1">
                                        Yes
                                    </label>
                                </div>
                                <div className="form-check custom-form-check">
                                    <input className="form-check-input" value="2" type="radio" name="exampleRadios" id="exampleRadios2" onChange={() => handleDeveloper(0)} />
                                    <label className="form-check-label fw-500" htmlFor="exampleRadios2" style={{cursor: "pointer"}}>
                                        No
                                    </label>
                                </div>
                                {verifyDevloper ?
                                    <span className='text-purple text-12'>
                                        *You will be required to upload these below documents:Balance sheet statement of 3 years, Income Tax Return of 3 years & Civil Score report
                                    </span>
                                    : null
                                }
                            </div>
                        </div>

                        <div className="col-12 mt-5 mt-lg-5 mb-4 mb-lg-0">
                            <div className="d-flex flex-column justify-content-center align-items-center" style={{cursor: "pointer"}}>
                                <button type="button" className="btn btn-purple-custom px-5 text-white" onClick={(e) => handleSubmitDevStep1(e)}>Submit</button>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </Layout >
    )
}

export default DevloperRegisterStepOne