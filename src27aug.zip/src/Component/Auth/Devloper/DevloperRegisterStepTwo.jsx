import React,{useEffect} from 'react'
import Layout from '../../Layout/Layout'

const DevloperRegisterStepTwo = () => {

    useEffect(() => {
        window.scrollTo(0, 0)
    }, [])

    return (
        <Layout>
            <div id="developer-reg-section" className="container-fluid margin-top-first-container-small form-section">
                <div className="container-lg py-4 py-lg-5">

                    <h2 className="text-start text-lg-center text-purple">Developer Registration</h2>
                    <hr className="hr-custom-two mx-lg-auto mb-4 mb-lg-5"></hr>


                    <div className="row g-3 g-lg-5">

                        <div className="col-12 col-sm-6 col-md-4">
                            <div className="card custom-form-card p-3">
                                <label htmlFor="exampleFormControlInput1" className="form-label mb-2">Tell us something about your firm</label>
                                <textarea className="form-control" id="exampleFormControlTextarea1" rows="3" placeholder="Your firm"></textarea>
                            </div>
                        </div>


                        <div className="col-12 col-sm-6 col-md-4">
                            <div className="card custom-form-card p-3">
                                <label htmlFor="exampleFormControlInput1" className="form-label mb-2"><span className="text-danger">* </span>Name of founder</label>
                                <input type="text" className="form-control" id="exampleFormControlInput1" placeholder="Enter Full Name" />
                            </div>
                        </div>

                        <div className="col-12 col-sm-6 col-md-4">
                            <div className="card custom-form-card p-3">
                                <label htmlFor="exampleFormControlInput1" className="form-label mb-2">Designation</label>
                                <input type="text" className="form-control" id="exampleFormControlInput1" placeholder="Enter Designation" />
                            </div>
                        </div>

                        <div className="col-12 col-sm-6 col-md-4">
                            <div className="card custom-form-card p-3">
                                <label htmlFor="exampleFormControlInput1" className="form-label mb-2">Qualification</label>
                                <input type="text" className="form-control" id="exampleFormControlInput1" placeholder="Enter qualifications" />
                            </div>
                        </div>

                        <div className="col-12 col-sm-6 col-md-4">
                            <div className="card custom-form-card p-3">
                                <label htmlFor="exampleFormControlInput1" className="form-label mb-2"><span className="text-danger">* </span>Years in service</label>
                                <div className="input-group mb-3">
                                    <input type="text" className="form-control input-group-first-input"
                                        placeholder="00" aria-label="Text input with dropdown button" />
                                    <span className="input-group-text" id="basic-addon2">Years</span>
                                </div>
                            </div>
                        </div>

                        <div className="col-12 col-sm-6 col-md-4">
                            <div className="card custom-form-card p-3 flex-row justify-content-around">
                                <label htmlFor="exampleFormControlInput1" className="form-label mb-2"><span className="text-danger">* </span>Photograph</label>
                                <button type="button" className="btn btn-orange-custom px-5 text-white" data-bs-toggle="modal" data-bs-target="#popup-select-upload-method">Upload</button>
                            </div>
                        </div>

                        <div className="col-12 col-sm-6 col-md-4">
                            <div className="card custom-form-card p-3">

                                <span className="custom-drag-box" >
                                    <i className="fa fa-file-image-o d-block custom-drag-box-icon" aria-hidden="true"></i>
                                    <span className="custom-drag-box-text">Photograph</span>
                                    <input type="file" onChange="dragNdrop(event)" onDragOver="drag()" onDrop="drop()" id="uploadFile" />
                                </span>
                            </div>
                        </div>

                        <div className="col-12 col-sm-6 col-md-4">
                            <div className="card custom-form-card p-3">
                                <button type="button" className="btn px-5 btn-gray-custom-inverse" >+ Add Founder</button>
                            </div>
                        </div>

                        <div className="col-12 col-sm-6 col-md-4">
                            <div className="card custom-form-card p-3">
                                <label htmlFor="exampleFormControlInput1" className="form-label mb-2"><span className="text-danger">* </span>Landmark projects</label>
                                <div className="input-group mb-3">
                                    <input type="text" className="form-control input-group-first-input"
                                        placeholder="00" aria-label="Text input with dropdown button" />
                                    <span className="input-group-text" id="basic-addon2">Years</span>
                                </div>
                            </div>
                        </div>

                        <div className="col-12 col-sm-6 col-md-4">
                            <div className="card custom-form-card p-3">
                                <label htmlFor="exampleFormControlInput1" className="form-label mb-2"><span className="text-danger">* </span>Completed projects</label>
                                <div className="input-group mb-3">
                                    <input type="text" className="form-control input-group-first-input"
                                        placeholder="00" aria-label="Text input with dropdown button" />
                                    <span className="input-group-text" id="basic-addon2">Years</span>
                                </div>
                            </div>
                        </div>

                        <div className="col-12 col-sm-6 col-md-4">
                            <div className="card custom-form-card p-3">
                                <label htmlFor="exampleFormControlInput1" className="form-label mb-2"><span className="text-danger">* </span>In-process projects</label>
                                <div className="input-group mb-3">
                                    <input type="text" className="form-control input-group-first-input"
                                        placeholder="00" aria-label="Text input with dropdown button" />
                                    <span className="input-group-text" id="basic-addon2">Years</span>
                                </div>
                            </div>
                        </div>

                        <div className="col-12 col-sm-6 col-md-4">
                            <div className="card custom-form-card p-3">
                                <label htmlFor="exampleFormControlInput1" className="form-label mb-2"><span className="text-danger">* </span>Documentation</label>
                                <div className="row">
                                    <div className="col-6 d-flex justify-content-center">
                                        <span className="custom-drag-box" >
                                            <i className="fa fa-file-image-o d-block custom-drag-box-icon" aria-hidden="true"></i>
                                            <span className="custom-drag-box-text">Balance sheet</span>
                                            <input type="file" onChange="dragNdrop(event)" onDragOver="drag()" onDrop="drop()" id="uploadFile" />
                                        </span>
                                    </div>
                                    <div className="col-6 d-flex justify-content-center">
                                        <span className="custom-drag-box" >
                                            <i className="fa fa-file-image-o d-block custom-drag-box-icon" aria-hidden="true"></i>
                                            <span className="custom-drag-box-text">CIBIL Report</span>
                                            <input type="file" onChange="dragNdrop(event)" onDragOver="drag()" onDrop="drop()" id="uploadFile" />
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="col-12">
                            <div className="d-flex flex-column justify-content-center align-items-center mb-4 mb-lg-3 mt-lg-2">
                                <button type="button" id="show-modal-button-1" className="btn btn-purple-custom px-5 text-white" data-bs-toggle="modal" data-bs-target="#popup-developer-registration-successful">Submit</button>
                            </div>
                        </div>

                    </div>
                </div>
            </div>

        </Layout>
    )
}

export default DevloperRegisterStepTwo