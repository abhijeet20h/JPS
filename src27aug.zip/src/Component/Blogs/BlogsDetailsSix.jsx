import React, { useEffect } from 'react';
import Layout from '../Layout/Layout';
import ImageSix from "../../assets/images/blog-img-6.jpg";

const BlogsDetailsSix = () => {

    useEffect(() => {
        window.scrollTo(0, 0)
    }, [])


    return (
        <Layout>
            <div id="blogs-details-section" className="blogs-details-section container-fluid margin-top-first-container-small">
        <div className="container-lg py-4 py-lg-5">
          <nav
            aria-label="breadcrumb"
            className="mb-0 mb-lg-4"
          >
            <ol className="breadcrumb">
              <li className="breadcrumb-item">
                <a href="index.html" className="text-black text-decoration-none fw-bold">Home</a>
              </li>
              <li className="breadcrumb-item active" aria-current="page">
                <span className="text-purple fw-bold">Blogs</span>
              </li>
            </ol>
          </nav>

          <div className="row">
            <div className="col-12 col-lg-6 pb-2 pt-0 pl-lg-4 d-flex flex-column justify-content-center">
              <div className="row">
                <div className="col-12">
                <h2 className="text-start text-lg-start mb-2 mb-lg-4 text-purple fw-bold">
                                Redevelopment - What matters more - % or Amenities or Balanced Expectations
                                </h2>
                                <hr className="hr-custom-one mb-3 mb-lg-4"></hr>
                </div>
                <div className="col-12  d-flex flex-column justify-content-start">
              <div className='mb-2'>
                  <span className="text-gray">Written By: </span><span>CA S Lakshminarayanan</span>
              </div>
              <div>
                  <span className="text-gray">Date: </span><span>22/02/2022</span>
              </div>
            </div>
              </div>
              
              
            </div>
            <div className="col-12 col-lg-6">
                            <div
                                className="p-3 border rounded-20 grow-cards-wrapper" style={{ backgroundImage: `url(${ImageSix})`, backgroundSize: 'cover' }}
                            >
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12 py-4 pb-0 text-333333">
                            <div class="static-wrap">
                                <p><strong>The topic today – </strong>Percentage of Amenities or both is like asking whether you want money or happiness or both.  Like the life question there is no perfect answer to this question too. However, in this article we would like to discuss few important parameters which will help us in getting close to the answer.
                                </p>
                                <p><strong>Percentage matters – </strong>Yes it matters a lot since that’s the wealth that you are creating in the Redevelopment process. A Bigger flat/ shop/ office means more wealth. Also, we have this obsession with percentage from our childhood – “kiti takke padle” which makes us look more closer to the percentage aspect over other parameters which are equally critical in Redevelopment. Having said that its important to have a balance percentage expectation which will enable the Project to move ahead smoothly, which will keep the Owners happy and one which keeps the Developer happy too.</p>

                            </div>

                            <div class="static-wrap">
                                <p>Other Parameters:</p>
                                <ol class="list-style-decimal">
                                    <li><strong>Construction Quality - </strong>Quality of construction should get equal if not more weightage in the Redevelopment process. While a bigger flat would mean more value for sure but a better-quality Flat would also mean more value since the Sale rate of good quality is usually higher.</li>
                                    <li><strong>Amenities which reduce Maintenance cost – </strong>More Amenities is better is what the general feeling is but what usually is seen is that Owners don’t end up using all Amenities and hence was better avoided so that Maintenance cost is also reduced.  Also, there are some Amenities like Solar, Parking with low maintenance, Biometric security system, etc. which reduces electricity bill & security bill simultaneously and hence reduces overall Maintenance cost thereby benefitting the Owners in the long run.</li>
                                </ol>
                            </div>

                            <div class="static-wrap">
                                <p>A Usual blend would be to get decent percentage increase as per Feasibility given by an experienced Architect and CA but also demand Amenities which will reduce the Maintenance cost of the Owners since Senior Citizens usually get bothered by the recurring Maintenance cost more than the percentage increase.</p>
                            </div>

                            <div class="static-wrap">
                                <p>For a list of better amenities & specifications.</p>
                                <p>Please contact <a href="tel:+917499553592" target='_blank'>7499553592</a> for more info or visit <a href="http://www.dreamsredeveloped.com" target='_blank'>www.dreamsredeveloped.com</a> for the same.</p>
                            </div>

                        </div>
                    </div>
                </div>
            </div>

        </Layout>
    )
}

export default BlogsDetailsSix