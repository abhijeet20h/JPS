import React, { useEffect } from 'react';
import Layout from '../Layout/Layout';
import ImageTwo from "../../assets/images/blog-img-2.jpg";

const BlogsDetailsTwo = () => {

    useEffect(() => {
        window.scrollTo(0, 0)
    }, [])


    return (
        <Layout>
            <div id="blogs-details-section" className="blogs-details-section container-fluid margin-top-first-container-small">
        <div className="container-lg py-4 py-lg-5">
          <nav
            aria-label="breadcrumb"
            className="mb-0 mb-lg-4"
          >
            <ol className="breadcrumb">
              <li className="breadcrumb-item">
                <a href="index.html" className="text-black text-decoration-none fw-bold">Home</a>
              </li>
              <li className="breadcrumb-item active" aria-current="page">
                <span className="text-purple fw-bold">Blogs</span>
              </li>
            </ol>
          </nav>

          <div className="row">
            <div className="col-12 col-lg-6 pb-2 pt-0 pl-lg-4 d-flex flex-column justify-content-center">
              <div className="row">
                <div className="col-12">
                <h2 className="text-start text-lg-start mb-2 mb-lg-4 text-purple fw-bold">
                                Redevelopment Process - Checklist and Relevant Regulations
                                </h2>
                                <hr className="hr-custom-one mb-3 mb-lg-4"></hr>
                </div>
                <div className="col-12  d-flex flex-column justify-content-start">
              <div className='mb-2'>
                  <span className="text-gray">Written By: </span><span>CA S Lakshminarayanan</span>
              </div>
              <div>
                  <span className="text-gray">Date: </span><span>22/02/2022</span>
              </div>
            </div>
              </div>
              
              
            </div>
            <div className="col-12 col-lg-6">
                            <div
                                className="p-3 border rounded-20 grow-cards-wrapper" style={{ backgroundImage: `url(${ImageTwo})`, backgroundSize: 'cover' }}
                            >
                            </div>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-12 py-4 pb-0 text-333333">
                            <div className="static-wrap">
                                <p>The Redevelopment process is an inward-looking process rather than an outward looking process.  In our experience and observation, quite a few Property owners are more concerned about what the neighboring plot has got during Redevelopment, how much profit will Developer earn, what will our neighboring flat owner get, etc. etc.  But during this whole process they forget the word ’Cooperative’ in the Cooperative Society completely.
                                </p>
                                <p>After having spoken to experienced people like Mr. Suhas Patwardhan (our knowledge partner), Secretary/ Chairman of Societies who have done successful Redevelopment, experienced Architects and experienced Lawyers who have worked comprehensively on Redevelopment process – the key in Redevelopment from a Property’s point of view is to get 100% consent which is key to an ideal beginning of the process.</p>
                            </div>

                            <div className="static-wrap">
                                <p>The ideal process summary for Redevelopment is enumerated below:</p>
                                <ol className="list-style-decimal">
                                    <li><strong>Consent from All Members – </strong>its absolutely necessary to involve, engage and get consent from 100% Members, if possible, to ensure a Smooth Redevelopment.</li>
                                    <li><strong>Choice of Redevelopment Managing Committee – </strong>As much as consent is necessary, every property irrespective of its size and peculiarity would require People to run the show.  This is where choice of good people to become part of Managing Committee is extremely important.</li>
                                    <li><strong>Feasibility Report – </strong>Feasibility report is a techno-financial report which provides insights into how much construction is possible as per the extant rules of UDCPR, what would be the construction cost, Is the project profitable for a Developer to participate and an estimate of how much increase in carpet area can the property owners expect after reasonable profit for Developer. However, these estimates can deviate in case of Developers with already existing Sales leads (since they have surety of Sale of inventory in this project), economics of cost if there are projects going nearby the plot, etc. Feasibility Report is a combination of expertise from an Architect (for Area calculations) and CA (for financial calculations). There are two major types of feasibility viz:</li>
                                    <ol className="list-style-lower-alpha">
                                        <li><strong>Normal Feasibility report – </strong>which contains majorly Area statement calculations, Cost calculations, DP Report, UDCPR rules summary, Potential of the Project. However, it lacks in one major aspect i.e., it doesn’t provide the potential of the project that can be actually consumed and Parking Fitment. This lacuna is however taken care by the next feasibility type.</li>
                                        <li><strong>Block Diagram Feasibility – </strong>This contains a block diagram providing Margins, Elevation, basic parking fitment potential along with the other things which a normal feasibility provides as per point no. 3 (a).  Because of the nature of the report this requires an experienced Architect who is well-versed with the rules of Construction in that area and hence is costlier than point no. 3(a) but much more effective hence <strong>highly recommended.</strong></li>
                                    </ol>
                                    <li><strong>Paperwork and Area statement – </strong>Legal due diligence of Property, Flats and Shops in terms of their paperwork completion is a necessary step for Redevelopment. Alongwith the same, having a clear understanding of each Owners Area is another hallmark of a good Redevelopment. Area is determined as per either one of these - Index II, Final Sanction plan or physical measurement. Each of the flat owners need to sign the Area Statement arrived at based on either the Index II / Final Sanction Plan / Physical Measurement (Mozni) so that is no ambiguity later.</li>
                                    <li><strong>Bidding – </strong>Having a transparent, fair, and neutral Bidding/ Tendering process is the hallmark of a good Redevelopment process. Right from providing all the Developers equal opportunity to provide their Proposal, to taking inputs from all owners within the property, this step is a lengthy, critical and quintessential process for a successful Redevelopment. Its quite essential to seek expectation from each and every owner in order to create a good Tender with all requirements getting captured appropriately.  Dreamsredeveloped provides a 160 point online bidding platform for exactly this reason.</li>
                                    <li><strong>Agreements – </strong>Having a good Lawyer/ CS/ CA on  your side to help in drafting or suggesting clauses in the Agreement, is the final step to ensure safeguard the Flat owners in case there is any issues that may be faced later.</li>
                                </ol>
                            </div>

                            <div className="static-wrap">
                                <p>This is the brief summary of the process. Dreamsredeveloped alongwith Pune Cooperative Housing Society Federation has created a detailed checklist for the same. You can mail your Society name, location and Secretary / Chairman Name and Contact Number on dreamsredeveloped@gmail.com to get the same on mail free of cost. In the next article you will be able to read about professionals that you require for ensuring a smooth redevelopment process.</p>
                                <p>Please contact <a href="tel:+917499553592">7499553592</a> for more info or visit <a href="http://www.dreamsredeveloped.com" target="_blank">www.dreamsredeveloped.com</a> for the same.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </Layout>
    )
}

export default BlogsDetailsTwo