import React from 'react';

const DashboardVideo = () => {
    return (
        <div id="video-section" className="video-section container-fluid">
            <div className="container-lg py-4 py-lg-5">
                <div className="row py-3 py-lg-5">
                    <div className="col-12 col-md-7 order-1 order-md-1">
                    <div className="video-container">
                    <iframe
                        className="slider-video rounded-40"
                        src="https://www.youtube.com/embed/r8hJi7x0zYs"
                        title="YouTube video player" frameBorder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowFullScreen
                    >
                    </iframe>
                </div> 
                        <div className="d-flex justify-content-end mt-2">
                            <a href="https://www.youtube.com/channel/UC2CW5ImZXjw88JqzpcsmN8A" target='_blank' className="fst-italic text-purple">View All</a>
                        </div>
                    </div>
                    <div className="col-12 col-md-5 order-2 order-md-2 d-flex align-items-center">
                        <div className="card p-3 border-0">
                            <a href="https://www.youtube.com/channel/UC2CW5ImZXjw88JqzpcsmN8A" className="text-decoration-none">
                                <h2 className="text-left text-purple mb-3 fw-bold">
                                    Experience the Luxury you Deserve
                                </h2></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default DashboardVideo;