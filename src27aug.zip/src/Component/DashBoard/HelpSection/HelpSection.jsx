import React from 'react';
import { useNavigate } from "react-router-dom";
import AdminRoutes from "../../../App/Route/RouteDetails";
import homeinterior from "../../../assets/images/home-interior.jpg"

const HelpSection = () => {
    const navigate = useNavigate();
    return (
        <div id="help-section" className="help-section container-fluid">
            <div className="container-lg py-4 py-lg-5">
                <h2 className="text-center text-purple fw-bold">Help Us Serve You!</h2>
                <hr className="hr-custom-one mx-auto mb-4 mb-lg-5" />
                <div className="row">
                    <div
                        className="col-12 col-md-6 px-lg-5 order-1 order-md-1 mb-4 mb-lg-0"
                    >
                        <input
                            type="image"
                            src={homeinterior}
                            className="img img-fluid rounded-40"
                            alt="photo"
                            srcSet=""
                        />
                    </div>
                    <div className="col-12 col-md-6 px-lg-5 order-2 order-md-2">
                        <div className="card choose-career-card p-3 pt-4 pb-4">
                            <h2 className="text-center text-lg-left text-purple fw-bold mb-3">
                                Choose Your Service
                            </h2>
                            <p>
                                <i className="fa fa-check" aria-hidden="true"></i><span className="fw-bold text-333333">Block Diagram Feasibility</span>
                            </p>
                            <p>
                                <i className="fa fa-check" aria-hidden="true"></i><span className="fw-bold text-333333">Paperwork and Area Statement</span>
                            </p>
                            <p>
                                <i className="fa fa-check" aria-hidden="true"></i><span className="fw-bold text-333333">Online, Transparent and Fast Bidding</span>
                            </p>
                            <p>
                                <i className="fa fa-check" aria-hidden="true"></i><span className="fw-bold text-333333">Curated Professional Service Network</span>
                            </p>
                            <div className="d-flex justify-content-center justify-content-lg-start mb-4 mb-lg-3 mt-lg-2" >
                                <a>
                                    <button type="button" className="btn btn-orange-custom px-5" onClick={() => navigate(AdminRoutes?.Wizard)}>
                                        Let's Begin!
                                    </button>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default HelpSection;