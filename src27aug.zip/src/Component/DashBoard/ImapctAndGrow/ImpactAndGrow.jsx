import React from 'react';
import { useNavigate } from "react-router-dom";
import AdminRoutes from '../../../App/Route/RouteDetails';
import ImageOne from "../../../assets/images/blog-img-1.jpg";
import ImageTwo from "../../../assets/images/blog-img-2.jpg";
import ImageThree from "../../../assets/images/blog-img-3.jpg";


const ImpactAndGrow = () => {
  const navigate = useNavigate();
  return (
    <>
      {/*Impact*/}
      <div id="impact-section" className="impact-section container-fluid">
        <div className="container-lg py-4 py-lg-5">
          <div className="row row-cols-md-3 py-4">
            <div
              className="col-12 col-sm-12 col-md col-lg-6 d-flex flex-column justify-content-center"
            >
              <h5 className="mb-3 text-center text-lg-start fw-bold">
                Impact We Have Created
              </h5>
              <p className="text-white">
                End-to-End services especially curated towards Senior Citizens with 180+ Societies Registered.
              </p>
            </div>

            <div className="col-12 col-sm-6 col-md col-lg-3 mb-3 mb-sm-0">
              <div className="card h-100  mx-0 py-4">
                <div className="card-body">
                  <h5 className="card-title text-white text-left">150+</h5>
                  <hr />
                  <p className="card-text text-white fw-bold">Societies<br />registered</p>
                </div>
              </div>
            </div>

            <div className="col-12 col-sm-6 col-md col-lg-3 mb-0 mb-sm-0">
              <div className="card h-100 mx-0 py-4">
                <div className="card-body">
                  <h5 className="card-title text-white text-left">40+</h5>
                  <hr />
                  <p className="card-text text-white fw-bold">Developers<br />onboarded<br /></p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/*Grow section*/}
      <div id="grow-section" className="grow-section container-fluid">
        <div className="container-lg py-4 py-lg-5">
          <h2 className="text-center mb-4 mb-lg-5 text-purple fw-bold pt-5">
            Grow more towards redevelopment
          </h2>
          <div className="row gx-5">
            <div className="col-12 col-md-4">
              <div className="p-3 border rounded-20 grow-cards-wrapper cursor-pointer" style={{ backgroundImage: `url(${ImageOne})`, backgroundSize: 'cover' }} onClick={() => navigate(AdminRoutes.BlogsDetailsOne)}>
                <div className="d-flex flex-column grow-cards m-auto">
                  <div className="mb-5 mb-lg-2">
                    <h5 className="fw-bold">Redevelopment - Why to go for it, who can go for it and how to go about it ?</h5>
                  </div>
                  <div className="d-flex flex-column justify-content-start">
                    <span>By CA S Lakshminarayanan</span>
                    <span>22/02/2022</span>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-12 col-md-4">
              <div className="p-3 border rounded-20 grow-cards-wrapper cursor-pointer" style={{ backgroundImage: `url(${ImageTwo})`, backgroundSize: 'cover' }} onClick={() => navigate(AdminRoutes.BlogsDetailsTwo)}>
                <div className="d-flex flex-column grow-cards m-auto">
                  <div className="mb-5 mb-lg-2">
                    <h5 className="fw-bold">Redevelopment Process - Checklist and Relevant Regulations</h5>
                  </div>
                  <div className="d-flex flex-column justify-content-start">
                    <span>By CA S Lakshminarayanan</span>
                    <span>22/02/2022</span>
                  </div>
                </div>
              </div>
            </div>



            <div className="col-12 col-md-4">
              <div className="p-3 border rounded-20 grow-cards-wrapper cursor-pointer" style={{ backgroundImage: `url(${ImageThree})`, backgroundSize: 'cover' }} onClick={() => navigate(AdminRoutes.BlogsDetailsThree)}>
                <div className="d-flex flex-column grow-cards m-auto">
                  <div className="mb-5 mb-lg-2">
                    <h5 className="fw-bold">Redevelopment - Professionals you need for the process and how to choose them</h5>
                  </div>
                  <div className="d-flex flex-column justify-content-start">
                    <span>By CA S Lakshminarayanan</span>
                    <span>22/02/2022</span>
                  </div>
                </div>
              </div>
            </div>

          </div>
          <p className="text-center text-lg-end mt-lg-5 pb-0">
            <span className="fst-italic text-purple viewllspan text-decoration-underline cursor-pointer" onClick={() => navigate(AdminRoutes?.Blogs)} >View All</span>
          </p>
        </div>
      </div>
    </>
  )
}

export default ImpactAndGrow;