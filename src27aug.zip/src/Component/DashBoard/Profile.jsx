import React from 'react'
import { useNavigate } from "react-router-dom";
import AdminRoutes from '../../App/Route/RouteDetails';
const Profile =()=> {
    const navigate = useNavigate();
  return (
    <div>

<div className="offcanvas offcanvas-end custom-profile-logout-menu" tabindex="-1" aria-labelledby="offcanvasRightLabel" data-bs-scroll="true" data-bs-backdrop="false">
				<div className="offcanvas-header justify-content-end">
					<button type="button" className="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
	    	</div>
				<div className="offcanvas-body">
					<div className="">
						<ul>  
							<li>								
								<div className="d-flex flex-row justify-content-start align-items-center"> <i  className="fa fa-user-circle-o me-3 user-pic" aria-hidden="true"></i> <span>Profile</span> </div>
							</li>
							<li>
                               <hr className="dropdown-divider m-0"></hr>
							</li>
							<li> <a href="#">Dashboard</a> </li>
							<li>  <span className='cursor-pointer'  onClick={() => navigate(AdminRoutes.DeveloperProfileDetails)}> Profile</span>

							</li>
							<li> <a href="#">Portfolio</a> </li>
							<li> <a href="#">Settings</a> </li>
							<li>
								<button type="button" className="btn btn-purple-custom py-1 px-2 text-12"><i className="fa fa-sign-out me-2" aria-hidden="true"></i>Logout</button>
							</li>
						</ul>
					</div>
				</div>
			</div>
    </div>
  )
}
export default Profile;