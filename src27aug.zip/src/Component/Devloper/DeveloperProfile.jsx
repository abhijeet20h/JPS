import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import Layout from '../Layout/Layout';
import AdminRoutes from "../../App/Route/RouteDetails";
import axios from 'axios';
import baseApi from '../../environment/Config';

const DeveloperProfile = () => {
    const navigate = useNavigate();
    const [formDevProfileErrors, setFormDevProfileErrors] = useState([]);
    const [isSubmitDevProfile, setIsSubmitDevProfile] = useState(false);
    const [spinner, setSpinner] = useState(false)
    const userInfo = JSON.parse(localStorage.getItem('drvalid'));


    useEffect(() => {
        window.scrollTo(0, 0)
    }, [])

    const validate = (DevValues) => {
        const errors = {};

        for (var i = 0; i < DevValues.length; i++) {
            if (DevValues[i].YearsInService) {
                console.log("object", DevValues[i].YearsInService)
            }

            else {
                errors.Photo = "All Fields Are Required!";
            }
        }


        for (var j = 0; j < DevValues.length; j++) {
            if (DevValues[j].Photo) {
                console.log("object", DevValues[j].Photo)
            }
            else {
                errors.Photo = "All Fields Are Required!";
            }
        }

        for (var q = 0; q < DevValues.length; q++) {
            if (DevValues[q].NameOfFounder) {
                console.log("object", DevValues[q].NameOfFounder)
            }
            else {
                errors.Photo = "All Fields Are Required!";
            }
        }

        return errors;
    };


    // *******Create Dynamic Component *********
    const [formDevProfileValues, setFormDevProfileValues] = useState([
        { id: 0, NameOfFounder: "", Qualification: "", YearsInService: "", Photo: "" },
    ]);

    const handleChangeInput = (index, event) => {
        const values = [...formDevProfileValues]
        values[index][event.target.name] = event.target.value;
        setFormDevProfileValues(values);
    }

    const handleAddFieldsWhatCourse = () => {
        console.log(formDevProfileValues.length);
        setFormDevProfileValues([...formDevProfileValues, { id: formDevProfileValues.length, NameOfFounder: "", Qualification: "", YearsInService: "", Photo: "" }])
    }

    const handleSubmit = async (e) => {
        e.preventDefault();
        setFormDevProfileErrors(validate(formDevProfileValues));
        setIsSubmitDevProfile(true);
    };


    // uploade all images
    const UploadDevImage = (index, e) => {
        setSpinner(true)

        var formdata = new FormData();
        formdata.append("file", e.target.files[0]);

        var requestOptions = {
            method: 'POST',
            body: formdata,
            redirect: 'follow'
        };

        fetch(`${baseApi.baseUrl}fileupload`, requestOptions)
            .then(response => response.text())
            .then(result => addImage(index, JSON.parse(result).file_path))
            .catch(error => console.log('error', error));

    };

    const addImage = (index, image) => {
        formDevProfileValues[index].Photo = image
        setSpinner(false)
    }


    // extra effect
    useEffect(() => {
        setFormDevProfileValues(formDevProfileValues);
    }, [spinner])


    
    // update devloper protfolio
    useEffect(() => {
        if (Object.keys(formDevProfileErrors).length === 0 && isSubmitDevProfile) {
            try {
                var data = JSON.stringify({
                    "partners_info": formDevProfileValues
                });

                var config = {
                    method: 'put',
                    url: `${baseApi.baseUrl}user/updateuser/${userInfo._id}`,
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    data: data
                };

                axios(config)
                    .then(function (response) {
                        if (response.data.message.includes('successfully')) {
                            navigate(AdminRoutes.DevloperProfileCompletion)
                        }
                    })
            } catch (err) {
                console.log(err)
            }
        }

    }, [formDevProfileErrors])

    const handleDelete = (index) => {
        const temparre = formDevProfileValues.filter(ele => ele.id !== index)

        console.log("@@@" , index)
        setFormDevProfileValues(temparre );
        
    }



useEffect(()=>{
    console.log(formDevProfileValues)
},[formDevProfileValues])




    return (
        <Layout>
            <div id="developer-reg-section" className="container-fluid margin-top-first-container-small form-section">
                <div className="container-lg py-4 py-lg-5">

                    <h2 className="text-start text-lg-center text-purple">Developer Registration</h2>
                    <hr className="hr-custom-two mx-lg-auto mb-4 mb-lg-5"></hr>

                    <div className="row g-3 g-lg-5">
                        <div className="col-12">
                            <div>
                                <div className="d-flex flex-row justify-content-between mb-2"> <span
                                    className="fw-bold text-purple fw-500 text-18">Profile</span> <span
                                        className="fst-italic fw-normal text-16">2 set of questions only</span> </div>
                                <div className="progress mb-4 rounded-20">
                                    <div className="progress-bar rounded-20 bg-orange" role="progressbar" style={{ width: '75%' }}
                                        aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                            </div>
                        </div>
                        <div className="col-12 mt-0">
                            <p className="fw-600">About Founder/Partner</p>
                            <p className="fw-400 fst-italic">Tell us something about yourself</p>
                        </div>

                        {formDevProfileValues?.map((val, index) => (
                            <div key={index}>
                                <div className="col-12 col-sm-6 offset-sm-3 col-md-4 offset-md-4">
                                    <div className="card custom-form-card p-3">
                                   
{  index !== 0 ?             <i className="fa fa-lg fa-times-circle align-self-end text-orange" id={"deleted" + index} aria-hidden="true" onClick={() => handleDelete(index)}></i> : null

}
                                        <br></br>
                                        <label htmlFor="exampleFormControlInput1" className="form-label mb-2"><span className="text-danger">* </span>Name of founder/partner</label>
                                        <input type="text" className="form-control" id="exampleFormControlInput1" placeholder="Enter Full Name" name="NameOfFounder" onChange={(event) => handleChangeInput(index, event)} />

                                        <br></br>

                                        <label htmlFor="exampleFormControlInput1" className="form-label mb-2">Qualification</label>
                                        <input type="text" className="form-control" id="exampleFormControlInput1" placeholder="Enter qualifications" name="Qualification" onChange={(event) => handleChangeInput(index, event)} />

                                        <br></br>

                                        <label htmlFor="exampleFormControlInput1" className="form-label mb-2"><span className="text-danger">* </span>Years in service</label>
                                        <div className="input-group mb-3">
                                            <input type="text" className="form-control input-group-first-input"
                                                placeholder="00" aria-label="Text input with dropdown button" name="YearsInService" onChange={(event) => handleChangeInput(index, event)} />
                                            <span className="input-group-text" id="basic-addon2">Years</span>
                                        </div>

                                        <br></br>

                                        <div className="d-flex flex-column align-items-start">
                                            <label htmlFor="exampleFormControlInput1" className="form-label mb-2"><span className="text-danger">* </span>Photo</label>
                                            {spinner && !val.Photo ?

                                                <>
                                                    <span className="custom-drag-box" >
                                                        <div className="spinner-grow text-warning" role="status">
                                                            <span className="sr-only">Loading...</span>
                                                        </div>
                                                        <input type="file" id="uploadFile" accept="image/png, image/gif, image/jpeg" onChange={(e) => UploadDevImage(index, e)} />
                                                    </span>
                                                </>
                                                :
                                                <>
                                                    {val.Photo ?
                                                        <span className="custom-drag-box w-100" >
                                                         
                                                            <div className="form-upload-photo-preview mt-3" style={{ backgroundImage: `url(${val.Photo})` }} ></div>
                                                            <input type="file" accept="image/png, image/gif, image/jpeg" id={"uploadFile" + index} name="Photo" onChange={(e) => UploadDevImage(index, e)} />
                                                        </span>
                                                        :
                                                        <span className="custom-drag-box w-100" >
                                                            <i className="fa fa-file-image-o d-block custom-drag-box-icon" aria-hidden="true"></i>
                                                            <span className="custom-drag-box-text">Photograph</span>
                                                            <input type="file" accept="image/png, image/gif, image/jpeg" id={"uploadFile" + index} name="Photo" onChange={(e) => UploadDevImage(index, e)} />
                                                        </span>
                                                    }
                                                </>
                                            }
                                        </div>
                                    </div>
                                </div>
                            </div>
                        ))}
                        <div className="col-8 offset-2 col-lg-4 offset-lg-4 text-center">
                            <button type="button" className="btn px-5 btn-gray-custom-inverse w-100" onClick={() => handleAddFieldsWhatCourse()}>Add Founder + </button>
                            <p className='text-danger text-center'>{formDevProfileErrors?.Photo}</p>
                            <button className="btn btn-purple-custom px-5 text-white w-100" onClick={(e) => handleSubmit(e)}>Next</button>
                        </div>



                    </div>
                </div>
            </div>
        </Layout>
    )
}

export default DeveloperProfile