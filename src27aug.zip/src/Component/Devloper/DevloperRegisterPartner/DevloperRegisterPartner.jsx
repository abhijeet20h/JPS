import React from 'react';

const DevloperRegisterPartner = () => {
    return (
        <div>DevloperRegisterPartner</div>
    )
}

export default DevloperRegisterPartner;