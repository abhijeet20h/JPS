import React, { useEffect } from 'react';
import Layout from '../Layout/Layout';

const DevloperVerification = () => {

    useEffect(() => {
        window.scrollTo(0, 0)
    }, [])

    return (
        <Layout>
            <div id="chairman-reg-section" className="container-fluid margin-top-first-container-small form-section">
                <div className="container-lg py-4 py-lg-5">

                    <h2 className="text-start text-lg-center text-purple">Developer Verification</h2>
                    <hr className="hr-custom-two mx-lg-auto mb-4 mb-lg-5"></hr>


                    <div className="row g-3 g-lg-5">


                        <div className="col-12 col-sm-6 col-md-4">
                            <div className="card custom-form-card p-3 flex-column align-items-center">
                                <label htmlFor="exampleFormControlInput1" className="form-label mb-2 text-start align-self-start"><span className="text-danger">* </span>Balance sheet</label>



                                <br></br>
                                <span className="custom-drag-box" >
                                    <i className="fa fa-file-image-o d-block custom-drag-box-icon" aria-hidden="true"></i>
                                    <span className="custom-drag-box-text">Balance sheet statement of 3 years</span>
                                    <input type="file" id="uploadFile" accept="image/png, image/gif, image/jpeg" />
                                </span>
                                <br></br>
                            </div>
                        </div>

                        <div className="col-12 col-sm-6 col-md-4">
                            <div className="card custom-form-card p-3 flex-column align-items-center">
                                <label htmlFor="exampleFormControlInput1" className="form-label mb-2 text-start align-self-start"><span className="text-danger">* </span>Income tax return</label>



                                <br></br>
                                <span className="custom-drag-box" >
                                    <i className="fa fa-file-image-o d-block custom-drag-box-icon" aria-hidden="true"></i>
                                    <span className="custom-drag-box-text">Income tax return of 3 years</span>
                                    <input type="file" id="uploadFile" accept="image/png, image/gif, image/jpeg" />
                                </span>
                                <br></br>
                            </div>
                        </div>

                        <div className="col-12 col-sm-6 col-md-4">
                            <div className="card custom-form-card p-3 flex-column align-items-center">
                                <label htmlFor="exampleFormControlInput1" className="form-label mb-2 text-start align-self-start"><span className="text-danger">* </span>Cibil Score report</label>

                                <br></br>
                                <span className="custom-drag-box" >
                                    <div className='d-flex flex-columns align-items-center'>
                                        <i className="fa fa-2x fa-check-circle me-2 text-orange text-20px" aria-hidden="true"></i>
                                        <span className="custom-drag-box-text">Uploaded</span>
                                        <input type="file" id="uploadFile" accept="image/png, image/gif, image/jpeg" />
                                    </div>
                                </span>
                                <br></br>

                                <br></br>
                                <span className="custom-drag-box" >
                                    <i className="fa fa-file-image-o d-block custom-drag-box-icon" aria-hidden="true"></i>
                                    <span className="custom-drag-box-text">Civil score report</span>
                                    <input type="file" id="uploadFile" accept="image/png, image/gif, image/jpeg" />
                                </span>
                                <br></br>
                            </div>
                        </div>

                        <div className="col-12">
                            <div className="d-flex flex-column justify-content-center align-items-center mb-4 mb-lg-3 mt-lg-2">
                                <button type="button" className="btn btn-purple-custom px-5 text-white" >Next</button>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </Layout >
    )
}

export default DevloperVerification;