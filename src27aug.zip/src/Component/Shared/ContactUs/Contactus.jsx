import React from 'react';
import SuccesModal from "../Modal/succesModal";

const Contactus = () => {
    return (
        <>
        {/*shoe succecss modal*/}
            <div className="modal fade" id="popup-contact-successful" tabIndex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <SuccesModal HeaderMsg="Thank you for contacting us." informMsg="We will revert you back as soon as possible." />
            </div>
            <div id="contact-us-section" className="faq-section container-fluid">
                <div className="container-lg py-4 py-lg-5">
                    <h2 className="text-center text-purple fw-bold pt-2 pt-lg-5">
                        Get in touch for next step
                    </h2>
                    <hr className="hr-custom-one mx-auto" />
                    <h4 className="text-center text-purple mb-4 mb-lg-5">We'll Call you Back</h4>
                    <div className="row">
                        <div className="offset-md-1 col-md-10 offset-lg-2 col-lg-8">
                            <div className="row g-3 g-lg-5 row-cols-1 row-cols-sm-2">
                                <div className="col">
                                    <div className="card custom-form-card p-3">
                                        <label htmlFor="exampleFormControlInput1" className="form-label mb-2">Name</label>
                                        <input type="text" className="form-control" id="exampleFormControlInput1" placeholder="Your Name" />
                                    </div>
                                </div>

                                <div className="col">
                                    <div className="card custom-form-card p-3">
                                        <label htmlFor="exampleFormControlInput1" className="form-label mb-2">Mobile Number</label>
                                        <input type="text" className="form-control" id="exampleFormControlInput1" placeholder="Your Mobile Number" />
                                    </div>
                                </div>

                                <div className="col">
                                    <div className="card custom-form-card p-3">
                                        <label htmlFor="exampleFormControlInput1" className="form-label mb-2">Society Name</label>
                                        <input type="text" className="form-control" id="exampleFormControlInput1" placeholder="Your Society Name" />
                                    </div>
                                </div>

                                <div className="col">
                                    <div className="card custom-form-card p-3">
                                        <label htmlFor="exampleFormControlInput1" className="form-label mb-2">Pincode</label>
                                        <input type="text" className="form-control" id="exampleFormControlInput1" placeholder="Enter Pin Code" />
                                    </div>
                                </div>
                            </div>
                            <div className="row mt-5">
                                <div className="col-12">
                                    <div className="d-flex flex-column justify-content-center align-items-center mb-4 mb-lg-3 mt-lg-2">
                                        <button type="button" className="btn btn-purple-custom px-5 text-white" data-bs-toggle="modal" data-bs-target="#popup-contact-successful">Submit</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default Contactus