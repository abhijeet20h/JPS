import React from 'react'
import signcheckicon from "../../../assets/images/sign-check-icon.png"

const SuccesModal = (props) => {
    return (
        <div className="modal-dialog modal-dialog-centered">
            <div className="modal-content bg-white border-white">
                <div className="modal-header border-bottom-0 justify-content-end"> <i className="fa fa-1x fa-times-circle cursor-pointer text-secondary" aria-hidden="true" data-bs-dismiss="modal" aria-label="Close"></i> </div>
                <div className="modal-body text-center">
                    <h3 className="mb-4 text-center text-green">{props.HeaderMsg}</h3>
                    <div className="d-flex flex-column align-items-center">
                        <p className="text-green">{props.informMsg}</p>
                        <div>
                            <input type="image" src={signcheckicon} alt="image" srcSet="" className="sign-check-icon" />
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default SuccesModal