import React, { useState, useRef } from 'react';
import axios from 'axios';
import Layout from '../../Layout/Layout'
import { useParams, useNavigate } from "react-router-dom";
import baseApi from '../../../environment/Config';
import { toast } from 'react-toastify';
import SuccesModal from "../Modal/succesModal";
import AdminRoutes from '../../../App/Route/RouteDetails';
import ConfigurationModal from '../Modal/ConfigurationModal';


const OtpVerifictionOwner = () => {
    const navigate = useNavigate();
    const { medium } = useParams();
    const [firstDigit, setFirstDigit] = useState();
    const [secondDigit, setSecondDigit] = useState();
    const [threeDigit, setThreeDigit] = useState();
    const [fourthDigit, setFourthDigit] = useState();
    const InputOne = useRef();
    const InputSecond = useRef();
    const InputThird = useRef();
    const InputFourth = useRef();

    // otp verification 
    const handleVerification = async () => {
        var data = JSON.stringify({
            "mobile": parseInt(medium), // number
            "roles": 2,
            "otp": parseInt(`${firstDigit}${secondDigit}${threeDigit}${fourthDigit}`)
        });

        var config = {
            method: 'post',
            url: `${baseApi.baseUrl}owner/ownervarification`,
            headers: {
                'Content-Type': 'application/json'
            },
            data: data
        };

        await axios(config)
            .then(function (response) {
                if (response.data.status === 1) {
                    localStorage.setItem("drvalid", JSON.stringify(response.data.data))
                    window.$('#popup-contact-successful').modal('show')
                    setTimeout(
                        showPopUp, 3000)
                } else {
                    toast(response.data.message);
                }
            })
            .catch(function (error) {
                if (error?.response) {
                    toast(error.response.data.message);
                }
            });
    }

    const showPopUp = () => {
        window.$('#popup-contact-successful').modal('hide')
        navigate(AdminRoutes.OwnerDashBoard)
    }


    // for the resend Otp 
    const handleresendotp = async () => {
        var data = JSON.stringify({
            "mobile": parseInt(medium),
            "roles": 2  // for owner role set 2
        });

        var config = {
            method: 'post',
            url: `${baseApi.baseUrl}owner/sendotp`,
            headers: {
                'Content-Type': 'application/json'
            },
            data: data
        };

        await axios(config)
            .then(function (response) {
                if (response.data.status === 1) {
                    toast(response.data.message);
                } else {
                    toast(response.data.message);
                }
            })
            .catch(function (error) {
                if (error?.response) {
                    toast(error.response.data.message);
                }
            });
    }



    const handleFirstDigit = (e) => {
        if (e.target.value.length === e.target.maxLength) {
            setFirstDigit(e.target.value)
            InputSecond.current.focus()
        }
    }


    const handleSecondDigit = (e) => {
        if (e.target.value.length === e.target.maxLength) {
            setSecondDigit(e.target.value)
            InputThird.current.focus()
        }
    }


    const handleThirdDigit = (e) => {
        if (e.target.value.length === e.target.maxLength) {
            setThreeDigit(e.target.value)
            InputFourth.current.focus()
        }
    }


    const handleFourthDigit = (e) => {
        if (e.target.value.length === e.target.maxLength) {
            setFourthDigit(e.target.value)
        }
    }



    return (
        <Layout>
            <div className="modal fade" id="popup-contact-successful" tabIndex="-1" aria-labelledby="popup-contact-successful" aria-hidden="true" >
                <SuccesModal HeaderMsg="Authentication Successful." informMsg="You have successfully login your account." />
            </div>
            <div className="modal fade" id="popup-society-configuration" tabIndex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <ConfigurationModal />
            </div>
            <div id="chairman-reg-section" className="container-fluid margin-top-first-container-small form-section">
                <div className="container-lg py-4 py-lg-5">

                    <h2 className="text-center text-purple">Property owner Verification</h2>
                    <hr className="hr-custom-two mx-auto mb-4 mb-lg-5"></hr>

                    <div className="row g-3 g-lg-5">
                        <div className="col-12">
                            <div className="card custom-form-card otp-card p-3 mx-auto">
                                <label className="form-label mb-2">Enter OTP send to </label>
                                <div className="row">
                                    <div className="col text-center">
                                        <input type="text" className="form-control otp-text-box text-center" aria-label="First name" maxLength="1" ref={InputOne} onChange={(e) => handleFirstDigit(e)} />
                                    </div>
                                    <div className="col text-cente">
                                        <input type="text" className="form-control otp-text-box text-center" aria-label="Last name" maxLength="1" ref={InputSecond} onChange={(e) => handleSecondDigit(e)} />
                                    </div>
                                    <div className="col text-cente">
                                        <input type="text" className="form-control otp-text-box text-center" aria-label="Last name" maxLength="1" ref={InputThird} onChange={(e) => handleThirdDigit(e)} />
                                    </div>
                                    <div className="col text-cente">
                                        <input type="text" className="form-control otp-text-box text-center" aria-label="Last name" maxLength="1" ref={InputFourth} onChange={(e) => handleFourthDigit(e)} />
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="col-12 mt-5 mt-lg-5 mb-2 mb-lg-0">
                            <div className="d-flex flex-column justify-content-center align-items-center">
                                <button type="button" className="btn btn-purple-custom px-5 text-white" onClick={() => handleVerification()} >Verify</button>
                            </div>
                        </div>

                        <div className="col-12 mt-2 mt-lg-3">
                            <div className="d-flex flex-column justify-content-center align-items-center">
                                <p className="mb-0">Didn’t receive OTP?</p>
                                <p className="mb-3 fw-500 cursor-pointer text-decoration-underline" onClick={() => handleresendotp()}>Re-send OTP</p>
                            </div>
                        </div>

                    </div>
                </div>
            </div>

        </Layout>
    )
}

export default OtpVerifictionOwner