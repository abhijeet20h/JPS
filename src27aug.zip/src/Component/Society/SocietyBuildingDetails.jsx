import React, { useState, useEffect } from 'react';
import Layout from '../Layout/Layout';
import axios from 'axios';
import baseApi from '../../environment/Config';
import { toast } from 'react-toastify';
import { useNavigate } from "react-router-dom";
import AdminRoutes from '../../App/Route/RouteDetails';

const SocietyBuildingDetails = () => {
    const navigate = useNavigate();
    const userInfo = JSON.parse(localStorage.getItem('drvalid'));

    const [setOne, setsetOne] = useState("previous");
    const [wings, setWings] = useState(0);
    const [floors, setFloors] = useState(0);
    const [units, setUnits] = useState(0);
    const [garage, setGarage] = useState(0);
    const [outHouse, setOutHouse] = useState(0);
    const [shops, setshops] = useState(0);
    const [offices, setOffice] = useState(0);

    useEffect(() => {
        window.scrollTo(0, 0)
    }, [])


    const handleSave = async (e) => {
        e.preventDefault();
        try {
            var data = JSON.stringify({
                "no_of_buildings": wings,
                "no_of_floors": floors,
                "no_of_flats": units,
                "garage": garage,
                "outhouse": outHouse,
                "shopes": shops,
                "offices": offices,
                "society_name": userInfo.data?.society_name,
                "location": userInfo.data?.location,
                "address": userInfo.data?.address,
                "choose_property": "Residential",
                // "propery_type": "Society/ Apartment",
                "gross_plot_area": userInfo.data?.gross_plot_area,
                "name": userInfo.data?.full_name,
                "appointment_letter": userInfo.data?.appointment_letter,
                "property_type": "Apartment",
                "society_photos": userInfo.data?.society_photos,
                "email": userInfo.data?.email,
                "mobile": userInfo.data?.mobile,
                "company_name": "",
                "entity_name": "",
                "Website": "",
                "service_year": 0,
                "building_info": {},
                "redevelopment_year": 0,
                "expertise": "",
                "company_logo": "",
                "Payment_Link_Id": "",
                "balance_sheet": "",
                "income_tax_return": "",
                "cibil_score": "",
                "partners_info": [],
                "roles": 1
            });

            var config = {
                method: 'put',
                url: `${baseApi.baseUrl}user/updateuser/${userInfo._id}`,
                headers: {
                    'Content-Type': 'application/json'
                },
                data: data
            };

            await axios(config)
                .then(function (response) {
                    toast("Profile Update Successfully");
                    localStorage.setItem("drvalid", JSON.stringify(response.data))
                    navigate(AdminRoutes.WingsDetails)
                })
        } catch (err) {
            console.log(err)
        }


    }

    const handleDcrement = (setValue, value) => {
        if (value) {
            setValue(value - 1)
        }
    }

    const handleIcrement = (setValue, value) => {
        setValue(value + 1)
    }

    return (
        <Layout>
            <div id="society-photos-page-section" className="society-photos-page-section container-fluid margin-top-first-container-small">
                <div className="container-lg py-4 py-lg-5">
                    <div className="row">
                        <div className="col-12 mb-3">
                            <div className="d-flex justify-content-between flex-row mb-2">
                                <div
                                    className="custom-id-card-01 text-purple d-flex flex-row align-items-center justify-content-start justify-content-lg-start">
                                    <div className="building-icon mr-3">
                                        <i className="fa fa-building" aria-hidden="true"></i>
                                    </div>
                                    <div className="building-text d-flex flex-column">
                                        <p className="mb-0 fw-600 text-16">Building Details</p>
                                    </div>
                                </div>
                            </div>

                            <div className="progress mb-4 rounded-20">
                                <div className="progress-bar rounded-20 bg-orange" role="progressbar" style={{ width: "75%" }} aria-valuenow="75"
                                    aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                    </div>


                    {setOne === "previous" ?
                        < div className="row g-3 g-lg-5">
                            <div className="col-12 col-sm-6 col-md-4">
                                <div className="card custom-form-card p-3">
                                    <label className="form-label">1. Number of buildings in your society?</label>
                                    <div className="input-group mb-3">
                                        <button className="input-group-text" onClick={() => handleDcrement(setWings, wings)}>-</button>
                                        <input type="text" className="form-control" placeholder="No. of wings" aria-label="Amount (to the nearest dollar)" value={wings} onChange={(e) => setWings(e.target.value)} />
                                        <button className="input-group-text" onClick={() => handleIcrement(setWings, wings)}>+</button>
                                    </div>
                                </div>
                            </div>
                            <div className="col-12 col-sm-6 col-md-4">
                                <div className="card custom-form-card p-3">
                                    <label className="form-label">2. No. of floors in each building</label>
                                    <div className="input-group mb-3">
                                        <button className="input-group-text" onClick={() => handleDcrement(setFloors, floors)}>-</button>
                                        <input type="text" className="form-control" placeholder="No. of floors" aria-label="Amount (to the nearest dollar)" value={floors} onChange={(e) => setFloors(e.target.value)} />
                                        <button className="input-group-text" onClick={() => handleIcrement(setFloors, floors)}>+</button>
                                    </div>
                                </div>
                            </div>
                            <div className="col-12 col-sm-6 col-md-4">
                                <div className="card custom-form-card p-3">
                                    <label className="form-label">3. No. of units on each floor</label>
                                    <div className="input-group mb-3">
                                        <button className="input-group-text" onClick={() => handleDcrement(setUnits, units)}>-</button>
                                        <input type="text" className="form-control" placeholder="No. of units" aria-label="Amount (to the nearest dollar)" value={units} onChange={(e) => setUnits(e.target.value)} />
                                        <button className="input-group-text" onClick={() => handleIcrement(setUnits, units)}>+</button>
                                    </div>
                                </div>
                            </div>
                            <div className="col-12 text-center mt-5 mt-lg-5 mb-4 mb-lg-0">
                                <button className="btn btn-purple-custom px-5" onClick={() => setsetOne("next")}>Next</button>
                            </div>
                        </div>

                        :

                        <>
                            <p className="mb-2 fw-600">Great !</p>
                            <p className="mb-2 fw-500">Society is taking shape well here !</p>


                            <div className="row g-3 g-lg-5">
                                <div className="col-12">
                                    <p className="mb-2  fw-500">1. Do you have any of these facilities?</p>
                                </div>
                                <div className="col-12 col-sm-6 col-md-4">
                                    <div className="card custom-form-card p-3">
                                        <p className="mb-2  fw-500">i. Garage</p>
                                        <div className="input-group mb-3">
                                            <button className="input-group-text" onClick={() => handleDcrement(setGarage, garage)}>-</button>
                                            <input type="text" className="form-control" placeholder="No. of garage" aria-label="Amount (to the nearest dollar)" value={garage} onChange={e => setGarage(e.target.value)} />
                                            <button className="input-group-text" onClick={() => handleIcrement(setGarage, garage)}>+</button>
                                        </div>
                                    </div>
                                </div>
                                <div className="col-12 col-sm-6 col-md-4">
                                    <div className="card custom-form-card p-3">
                                        <p className="mb-2  fw-500">ii. Outhouse</p>
                                        <div className="input-group mb-3">
                                            <button className="input-group-text" onClick={() => handleDcrement(setOutHouse, outHouse)}>-</button>
                                            <input type="text" className="form-control" placeholder="No. of outhouse" aria-label="Amount (to the nearest dollar)" value={outHouse} onChange={e => setOutHouse(e.target.value)} />
                                            <button className="input-group-text" onClick={() => handleIcrement(setOutHouse, outHouse)}>+</button>
                                        </div>
                                    </div>
                                </div>
                                <div className="col-12 col-sm-6 col-md-4">
                                    <div className="card custom-form-card p-3">
                                        <p className="mb-2  fw-500">iii. Shops</p>
                                        <div className="input-group mb-3">
                                            <button className="input-group-text" onClick={() => handleDcrement(setshops, shops)}>-</button>
                                            <input type="text" className="form-control" placeholder="No. of shops" aria-label="Amount (to the nearest dollar)" value={shops} onChange={e => setshops(e.target.value)} />
                                            <button className="input-group-text" onClick={() => handleIcrement(setshops, shops)}>+</button>
                                        </div>
                                    </div>
                                </div>
                                <div className="col-12 col-sm-6 col-md-4">
                                    <div className="card custom-form-card p-3">
                                        <p className="mb-2  fw-500">iv. Offices</p>
                                        <div className="input-group mb-3">
                                            <button className="input-group-text" onClick={() => handleDcrement(setOffice, offices)}>-</button>
                                            <input type="text" className="form-control" placeholder="No. of offices" aria-label="Amount (to the nearest dollar)" value={offices} onChange={e => setOffice(e.target.value)} />
                                            <button className="input-group-text" onClick={() => handleIcrement(setOffice, offices)}>+</button>
                                        </div>
                                    </div>
                                </div>

                                <div className="col-12 text-center mt-5 mt-lg-5 mb-4 mb-lg-0">
                                    <button className="btn btn-purple-custom px-5" onClick={(e) => handleSave(e)}>Save</button>
                                </div>
                            </div>
                        </>
                    }
                </div>

            </div>
        </Layout >
    )
}

export default SocietyBuildingDetails;