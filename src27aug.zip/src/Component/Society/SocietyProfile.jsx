import React ,{useState, useEffect} from 'react'
import Layout from '../Layout/Layout'
import PlaceholderImage from '../../assets/images/Placeholder-image.png'
import axios from 'axios';
import baseApi from '../../environment/Config';
import AdminRoutes from '../../App/Route/RouteDetails';
import { useNavigate } from "react-router-dom";

export default function SocietyProfile() {
    const [getAllinfo, setGetAllInfo] = useState('');
    const [buildingInfo, setBuildingInfo] = useState('');
    const navigate = useNavigate();

    const userInfo = JSON.parse(localStorage.getItem('drvalid'));

    useEffect(() => {
        window.scrollTo(0, 0)
        SocietyProfile()
    }, [])

    useEffect(() => {
      console.log()
    }, [])
    const SocietyProfile = async () => {
        try {
            var data = JSON.stringify({
                "_id": userInfo._id
            });
    var config = {
        method: 'post',
        url: `${baseApi.baseUrl}user/getinfobyid`,
        headers: {
            'Content-Type': 'application/json'
        },
        data: data  
    };
    
            await axios(config)
                .then(function (response) {
                    setGetAllInfo(response.data?.data[0])
                    setBuildingInfo(response.data?.data[0].building_info)
                })
        } catch (err) {
            console.log(err)
        }
    }

    const onViewHandle = () => {
         navigate(AdminRoutes?.SocietyFlatOwnerView)
    }

    return (
        <Layout>
            <div id="society-overview-page-section"
                className="society-overview-page-section container-fluid margin-top-first-container-large">
                <div className="container-lg py-4 py-lg-5">

                    <div className="row">
                        <div className="col-12 mb-3">
                            <div className="d-flex justify-content-start align-items-center flex-row mb-2">
                                <div
                                    className="custom-id-card-01 text-purple d-flex flex-row align-items-center justify-content-start justify-content-lg-start me-4">
                                    <div className="building-icon mr-3">
                                        <i className="fa fa-building" aria-hidden="true"></i>
                                    </div>
                                    <div className="building-text d-flex flex-column">
                                        <p className="mb-0 fw-600 text-16">{getAllinfo?.society_name}</p>
                                        <p className="mb-0 fw-400">{getAllinfo?.address?.Area} {getAllinfo?.address?.State} {getAllinfo?.address?.PinNo}</p>
                                    </div>
                                </div>
                                <i class="fa fa-lg fa-pencil-square-o" aria-hidden="true"></i>
                            </div>

                            
                            <p className="mb-0 mt-4 fst-italic fw-600 text-16">Your society looks like this....</p>
                        </div>
                    </div>

                    <div className="row mb-5 gy-3 gy-lg-auto">
                        <div className="col-12 col-sm-6 col-md-4">
                            <div className="counter-card-2 p-3 bg-light border rounded-3">
                                <h3>{getAllinfo?.no_of_buildings}</h3>
                                <p>No. of buildings</p>
                            </div>

                        </div>
                        <div className="col-12 col-sm-6 col-md-4">
                            <div className="counter-card-2 p-3 bg-light border rounded-3">
                                <h3>{getAllinfo?.no_of_flats * getAllinfo?.no_of_floors}</h3>
                                <p>Total No. of units</p>
                            </div>
                        </div>
                    </div>

                    <div className="d-flex flex-row justify-content-between mb-3">
                        <span className="fw-600">Photo gallery</span>
                        <span className='text-decoration-underline'>See all <i class="fa fa-angle-right" aria-hidden="true"></i></span>
                    </div>

                    <div className="row mb-5 gy-3 gy-lg-auto">
                        < div className="col-12 col-lg-3">
                            <div className="counter-card-2">
                                <img src={PlaceholderImage} className="img-fluid rounded-3" alt="image" />
                            </div>

                        </div>

                        <div className="col-12 col-lg-3">
                            <div className="counter-card-2">
                                <img src={PlaceholderImage} className="img-fluid rounded-3" alt="image" />
                            </div>
                        </div>

                        <div className="col-12 col-lg-3">
                            <div className="counter-card-2">
                                <img src={PlaceholderImage} className="img-fluid rounded-3" alt="image" />
                            </div>
                        </div>
                        <div className="col-12 col-lg-3">
                            <div className="counter-card-2">
                                <img src={PlaceholderImage} className="img-fluid rounded-3" alt="image" />
                            </div>
                        </div>

                    </div>
                    <hr className="hr-custom-two mx-lg-auto mb-4 mb-lg-5"></hr>

                    {/*
                <p className="fw-600">Wings/Buildings</p>
                    <div className="row mb-5 gy-3 gy-lg-auto">
                        <div className="col-12 col-lg-3">
                            <div className="p-3 bg-light border-orange rounded-3">
                                A1
                            </div>
                        </div>
                        <div className="col-12 col-lg-3">
                            <div className="p-3 bg-light border-orange rounded-3">
                                A2
                            </div>
                        </div>
                        <div className="col-12 col-lg-3">
                            <div className="p-3 bg-light border-orange rounded-3">
                                A3
                            </div>
                        </div>
                        <div className="col-12 col-lg-3">
                            <div className="p-3 bg-light border-orange rounded-3">
                                A4
                            </div>
                        </div>
                    </div>
                */}
                    <div className="row mb-3">
                        <div className="col-12 col-lg-6 offset-lg-3">
                            <h4 className='mb-4'>Owners Listing</h4>
                            <div className="d-flex flex-row justify-content-between justify-content-sm-start align-items-center">
                                <div>
                                    <p className="fw-600 text-purple me-0 me-sm-3">Wing: </p>
                                </div>
                                <div>
                                    <div className="input-group mb-3">
                                        <select className="form-select fw-400 pe-5" aria-label="Default select example">
                                            <option value="1">A1</option>
                                            <option value="2">A2</option>
                                            <option value="3">A3</option>
                                            <option value="4">A4</option>
                                        </select>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div className="row mb-4">
                        <div className="col-12 col-lg-6 offset-lg-3">
                            <div className="d-flex flex-row justify-content-between align-items-center">
                                <p className='d-inline-block'>Total No of Members: 15</p>
                                <div className="input-group w-auto">
                                    <input type="text" className="form-control" aria-describedby="basic-addon2" />
                                    <span className="input-group-text bg-light" id="basic-addon2"><i className="fa fa-search" aria-hidden="true"></i></span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="row mb-4">
                        <div className="col-12 col-lg-6 offset-lg-3">
                            <div className="d-flex flex-row align-items-center justify-content-between">
                                <div className="custom-id-card-01 text-purple d-flex flex-row align-items-center justify-content-start justify-content-lg-start">
                                    <div className="building-icon mr-3">
                                        <i className="fa fa-user-circle-o" aria-hidden="true"></i>
                                    </div>
                                    <div className="building-text d-flex flex-column">
                                        <p className="mb-0 fw-600 text-16">Rajiv Jha</p>
                                        <p className="mb-0 fw-400 text-14">Chairman</p>
                                    </div>
                                </div>
                                <button onClick={()=>onViewHandle()}  className='btn btn-sm btn-white-custom'>View</button>
                            </div>
                        </div>
                    </div>

                    <div className="row">
                        <div className="col-12 col-lg-6 offset-lg-3">
                            <p className='d-inline-block'>View all members (10 more)</p>
                            <hr className="hr-custom-two mx-lg-auto mb-4 mb-lg-5"></hr>
                        </div>
                    </div>



                </div>
            </div>
        </Layout>
    )
}
