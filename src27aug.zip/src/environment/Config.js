const baseApi = {};
baseApi.baseUrl = 'http://43.205.53.236:4000/';
// baseApi.baseUrl = 'http://192.168.2.220:4000/';
baseApi.baseUrl = 'https://development.dreamsredeveloped.com:4443/';
// baseApi.baseUrl = "https://7f1f-103-239-87-226.in.ngrok.io"
baseApi.razorpay = 'https://api.razorpay.com/v1/payment_links';
export default baseApi;
